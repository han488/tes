<?php
// user/riwayat.php - Riwayat Peminjaman User (SIMPLE NO LIMIT ISSUE)
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    redirect('../index.php');
}

$user_id = $_SESSION['user_id'];

// Fetch history SIMPLE - no pagination to avoid LIMIT issues
$stmt = $pdo->prepare("SELECT p.*, a.nama as alat_nama, a.foto FROM peminjaman p JOIN alat a ON p.alat_id = a.id WHERE p.user_id = ? ORDER BY p.created_at DESC");
$stmt->execute([$user_id]);
$history = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Peminjaman - Alat Tani</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">


</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-success">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-arrow-left me-2"></i>Kembali Dashboard
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    Halo, <?php echo htmlspecialchars($_SESSION['username']); ?>
                </span>
                <a class="nav-link" href="../logout.php">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <i class="bi bi-clock-history me-2 text-primary"></i>
                Riwayat Peminjaman (<?php echo count($history); ?> record)
            </h2>
            <div class="btn-group" role="group">
                <a href="dashboard.php" class="btn btn-warning text-dark fw-bold shadow-lg">
                    <i class="bi bi-house-door"></i> Dashboard
                </a>

            </div>
        </div>

        <?php if (empty($history)): ?>
            <div class="text-center py-5">
                <i class="bi bi-clock-history fs-1 text-muted mb-3"></i>
                <h4 class="text-muted">Belum ada riwayat peminjaman</h4>
                <p class="text-muted">Mulai pinjam alat dari dashboard untuk melihat riwayat</p>
                <a href="dashboard.php" class="btn btn-success">
                    <i class="bi bi-tools"></i> Lihat Alat Tersedia
                </a>
            </div>
        <?php else: ?>
        <div class="shopee-card">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="bg-shopee text-white">

                        <tr>
                            <th>Foto</th>
                            <th>Alat</th>
                            <th>Periode Sewa</th>
                            <th>Durasi</th>
                            <th>Biaya</th>
                            <th>Metode Bayar</th>
                            <th>Bukti Transfer</th>
                            <th>Denda</th>
                            <th>Status</th>
                            <th>Dibuat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history as $row): ?>
                        <tr>
                            <td>
                                <?php if ($row['foto']): ?>
                                    <img src="../uploads/<?php echo htmlspecialchars($row['foto']); ?>" class="alat-img-table rounded shadow-sm img-fluid" style="width: 60px; height: 60px; object-fit: cover;">


                                <?php else: ?>
                                    <div class="bg-light rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width:60px;height:60px;">
                                        <i class="bi bi-tools text-muted fs-4"></i>
                                    </div>

                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['alat_nama']); ?></strong>
                                <br><small class="text-muted">ID #<?php echo $row['id']; ?></small>
                            </td>
                            <td>
                                <small class="fw-bold"><?php echo date('d/m/Y', strtotime($row['tgl_mulai'])); ?></small><br>
                                <small class="text-muted">s/d <?php echo date('d/m/Y', strtotime($row['tgl_selesai'])); ?></small>
                            </td>
                            <td>
                                <span class="badge bg-info fs-6"><?php echo $row['total_hari']; ?> hari</span>
                            </td>
                            <td>
                                <strong class="text-success">
                                    Rp <?php echo number_format($row['total_biaya'], 0, ',', '.'); ?>
                                </strong>
                            </td>
                            <td>
                                <?php if ($row['denda'] > 0): ?>
                                    <span class="badge bg-danger fs-6">
                                        Rp <?php echo number_format($row['denda'], 0, ',', '.'); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success fs-6">Rp 0</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $status = $row['status'];
                                    $badgeClass = match($status) {
                                        'dikembalikan' => 'success',
                                        'dipinjam' => 'warning', 
                                        'booking' => 'info',
                                        'rejected' => 'danger',
                                        default => 'secondary'
                                    };
                                ?>
                                <span class="badge bg-<?php echo $badgeClass; ?> fs-6">
                                    <?php echo ucfirst($status); ?>
                                </span>
                            </td>
                            <td>
                                <small class="text-muted">
                                    <?php echo date('d/m/Y H:i', strtotime($row['created_at'])); ?>
                                </small>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="text-center mt-4">
                <small class="text-muted">
                    Total <?php echo count($history); ?> record | 
                    <a href="dashboard.php" class="text-decoration-none">← Kembali Dashboard</a>
                </small>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

