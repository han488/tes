<?php
// user/pinjam.php - ULTIMATE EDITION with Category Filter, Search, Detail Cards, Load More
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    redirect('../index.php');
}

$user_id = $_SESSION['user_id'];
$message = '';
$page = ($_GET['page'] ?? 1);
$per_page = 12;
$offset = ($page - 1) * $per_page;
$search = $_GET['search'] ?? '';
$kategori = $_GET['kategori'] ?? '';

// Search + category filter
$where = "WHERE a.stok > 0";
$params = [];
if ($search) {
    $where .= " AND a.nama LIKE ?";
    $params[] = "%$search%";
}
if ($kategori) {
    $where .= " AND a.kategori_id = ?";
    $params[] = $kategori;
}

$alat_query = "SELECT a.*, k.nama as kat_nama FROM alat a JOIN kategori k ON a.kategori_id = k.id $where ORDER BY a.nama LIMIT $per_page OFFSET $offset";
$stmt = $pdo->query($alat_query);
$alat_list = $stmt->fetchAll();

$total_query = "SELECT COUNT(*) FROM alat a JOIN kategori k ON a.kategori_id = k.id $where";
$stmt = $pdo->query($total_query);
$total_alat = $stmt->fetchColumn();
$total_pages = ceil($total_alat / $per_page);

$kategori_list = $pdo->query("SELECT * FROM kategori ORDER BY nama")->fetchAll();

// Handle form submit PINJAM
if ($_POST['action'] ?? '' === 'pinjam') {
    $alat_id = (int)$_POST['alat_id'];
    $tgl_mulai = $_POST['tgl_mulai'];
    $tgl_selesai = $_POST['tgl_selesai'];
    
    // Validate
    if (empty($tgl_mulai) || empty($tgl_selesai) || $alat_id <= 0) {
        $message = '<div class="alert alert-danger shadow-lg"><i class="bi bi-exclamation-triangle me-2"></i>Tanggal atau alat tidak valid!</div>';
    } elseif (strtotime($tgl_selesai) < strtotime($tgl_mulai)) {
        $message = '<div class="alert alert-warning shadow-lg"><i class="bi bi-calendar-x me-2"></i>Tanggal akhir harus > mulai!</div>';
    } else {
        // Check stok + lock
        $stmt = $pdo->prepare("SELECT nama, stok, harga_sewa_per_hari FROM alat WHERE id = ? AND stok > 0 FOR UPDATE");
        $stmt->execute([$alat_id]);
        $alat = $stmt->fetch();
        
        if (!$alat) {
            $message = '<div class="alert alert-danger shadow-lg"><i class="bi bi-x-circle me-2"></i>⚠️ Alat tidak tersedia atau stok habis!</div>';
        } else {
            $total_hari = (strtotime($tgl_selesai) - strtotime($tgl_mulai)) / 86400 + 1;
            $total_biaya = $total_hari * $alat['harga_sewa_per_hari'];
            
            $pdo->beginTransaction();
            try {
                // Insert booking
                $stmt = $pdo->prepare("
                    INSERT INTO peminjaman (user_id, alat_id, tgl_mulai, tgl_selesai, total_hari, total_biaya, status) 
                    VALUES (?, ?, ?, ?, ?, ?, 'booking')
                ");
                $stmt->execute([$user_id, $alat_id, $tgl_mulai, $tgl_selesai, $total_hari, $total_biaya]);
                $booking_id = $pdo->lastInsertId();
                
                // Reduce stok
                $pdo->prepare("UPDATE alat SET stok = GREATEST(stok - 1, 0) WHERE id = ?")->execute([$alat_id]);
                
                $pdo->commit();
                $message = '<div class="alert alert-success shadow-lg border-start border-success border-5 animate__animated animate__fadeIn">
                    <i class="bi bi-check-circle-fill me-2"></i>✅ Booking berhasil! #<strong>' . $booking_id . '</strong><br>
                    <small class="opacity-75">Stok sudah dikurangi. Tunggu approval admin. <a href="riwayat.php" class="text-decoration-none fw-semibold">Cek Riwayat →</a></small>
                </div>';
            } catch (Exception $e) {
                $pdo->rollBack();
                $message = '<div class="alert alert-danger shadow-lg">❌ Error booking: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pinjam Alat Pertanian - Alat Tani Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
    <style>
        :root {
            --shopee-orange: #EE4D2D;
            --shopee-gradient: linear-gradient(135deg, #EE4D2D, #FF6B35);
        }
body {
            background: linear-gradient(135deg, #FFF2F2 0%, #FFE8E6 50%, #FFF7F4 100%);
            min-height: 100vh;
        }
        .floating-particle {
            position: fixed;
            background: radial-gradient(circle, rgba(238,77,45,0.3) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            animation: float 20s infinite linear;
            z-index: -1;
        }
        @keyframes float {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
        }
        .alat-card {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.8);
            transition: all 0.4s cubic-bezier(0.25,0.46,0.45,0.94);
            position: relative;
            overflow: hidden;
        }
        .alat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transition: 0.6s;
        }
        .alat-card:hover::before {
            left: 100%;
        }
        .alat-card:hover {
            transform: translateY(-15px) scale(1.02);
            box-shadow: 0 30px 80px rgba(238,77,45,0.4);
        }
        .alat-img {
            height: 220px;
            object-fit: cover;
            transition: transform 0.4s ease;
        }
        .alat-card:hover .alat-img {
            transform: scale(1.05);
        }
        .search-box {
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.6);
            border-radius: 25px;
            transition: all 0.3s ease;
        }
        .search-box:focus-within {
            box-shadow: 0 10px 40px rgba(238,77,45,0.3);
            transform: translateY(-2px);
        }
        .kategori-btn {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 25px;
            transition: all 0.3s ease;
        }
        .kategori-btn.active, .kategori-btn:hover {
            background: var(--shopee-gradient);
            border-color: var(--shopee-orange);
            transform: translateY(-2px);
        }
        .pagination-btn {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 50px;
            transition: all 0.3s ease;
        }
        .pagination-btn:hover:not(:disabled) {
            background: var(--shopee-gradient);
            transform: translateY(-2px);
        }
        .modal-content {
            background: rgba(255,255,255,0.98);
            backdrop-filter: blur(30px);
            border: 1px solid rgba(255,255,255,0.95);
            box-shadow: 0 25px 100px rgba(238,77,45,0.3);
            animation: modalPop 0.4s cubic-bezier(0.25,0.46,0.45,0.94);
        }
        @keyframes modalPop {
            from { transform: scale(0.8) translateY(30px); opacity: 0; }
            to { transform: scale(1) translateY(0); opacity: 1; }
        }
        .price-badge {
            background: var(--shopee-gradient);
            color: white;
            font-weight: 700;
            padding: 8px 16px;
            border-radius: 25px;
            font-size: 0.9rem;
        }
        @media (max-width: 768px) {
            .alat-card:hover {
                transform: translateY(-10px) !important;
            }
        }
    </style>
</head>
<body>
    <!-- Floating Particles -->
    <?php for($i = 0; $i < 10; $i++): ?>
        <div class="floating-particle" style="left: <?php echo rand(0,100); ?>%; animation-delay: <?php echo rand(0,20); ?>s; animation-duration: <?php echo rand(15,25); ?>s; width: <?php echo rand(20,60); ?>px; height: <?php echo rand(20,60); ?>px;"></div>
    <?php endfor; ?>
    
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4" style="background: var(--shopee-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">
                <i class="bi bi-person-circle me-2"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
            </h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dashboard
            </a>
            <a href="pinjam.php" class="nav-item active">
                <i class="bi bi-calendar-plus nav-icon"></i> Pinjam Alat
            </a>
            <a href="riwayat.php" class="nav-item">
                <i class="bi bi-clock-history nav-icon"></i> Riwayat
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content p-4 p-lg-5">
        <div class="header mb-5">
            <div class="row align-items-center g-3">
                <div class="col">
                    <h1 class="text-white mb-1" style="font-size: 2.5rem; font-weight: 800;">
                        <i class="bi bi-calendar-plus-fill me-3 text-warning" style="font-size: 3rem;"></i>
                        Pinjam Alat Pertanian
                    </h1>
                    <p class="text-white-50 mb-0 lead">Stok real-time • Booking instan • Approval cepat</p>
                </div>
                <div class="col-auto">
                    <span class="badge bg-warning fs-6 px-3 py-2">
                        <i class="bi bi-arrow-clockwise me-1"></i><?php echo count($alat_list); ?> Alat Tersedia
                    </span>
                </div>
            </div>
        </div>
        
        <?php if ($message): echo $message; endif; ?>
        
        <!-- Search & Filter -->
        <div class="card mb-5 shadow-xl border-0" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.2); border-radius: 24px;">
            <div class="card-body p-4">
                <div class="row g-3 align-items-center">
                    <div class="col-lg-5">
                        <div class="search-box">
                            <i class="bi bi-search position-absolute ms-3 mt-3 text-muted"></i>
                            <input type="text" class="form-control ps-5 border-0 bg-transparent shadow-none" placeholder="Cari alat tani..." id="searchInput">
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="d-flex gap-2 flex-wrap" id="kategoriFilter">
                            <button class="btn kategori-btn active px-4 py-2 text-white fw-semibold" data-kat="">Semua Kategori</button>
                            <?php foreach ($kategori_list as $kat): ?>
                                <button class="btn kategori-btn px-4 py-2 text-white fw-semibold shadow-sm" data-kat="<?php echo $kat['id']; ?>">
                                    <?php echo htmlspecialchars($kat['nama']); ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <button class="btn btn-shopee w-100 px-4" onclick="location.reload()">
                            <i class="bi bi-arrow-clockwise me-2"></i>Refresh Stok
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Alat Grid -->
        <div class="alat-grid row g-4 alat-sync" id="alatGrid">
            <?php foreach ($alat_list as $alat): ?>
                <div class="col-xl-3 col-lg-4 col-md-6 alat-card-item" data-kat="<?php echo $alat['kategori_id']; ?>" data-search="<?php echo strtolower($alat['nama']); ?>">
                    <div class="alat-card h-100 rounded-3 shadow-lg">
                        <!-- Image -->
                        <div class="position-relative overflow-hidden rounded-top-3">
                            <?php if ($alat['foto'] && file_exists('../uploads/' . $alat['foto'])): ?>
                                <img src="../uploads/<?php echo htmlspecialchars($alat['foto']); ?>" class="alat-img w-100" alt="<?php echo htmlspecialchars($alat['nama']); ?>">
                            <?php else: ?>
                                <div class="d-flex align-items-center justify-content-center bg-gradient text-white rounded-top-3" style="height: 200px;">
                                    <i class="bi bi-tools fs-1 opacity-75"></i>
                                </div>
                            <?php endif; ?>
                            <!-- Stok Badge -->
                            <div class="position-absolute top-3 end-3">
                                <span class="badge bg-<?php echo $alat['stok'] > 3 ? 'success' : ($alat['stok'] > 0 ? 'warning' : 'danger'); ?> fs-6 px-3 py-2 rounded-pill shadow">
                                    Stok <strong><?php echo $alat['stok']; ?></strong>
                                </span>
                            </div>
                        </div>
                        
                        <!-- Content -->
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="fw-bold text-dark mb-0" style="font-size: 1.1rem; line-height: 1.3;"><?php echo htmlspecialchars($alat['nama']); ?></h6>
                                <span class="badge bg-success"><?php echo htmlspecialchars($alat['kat_nama']); ?></span>
                            </div>
                            <p class="text-muted small mb-3"><?php echo htmlspecialchars(substr($alat['deskripsi'] ?? 'Alat pertanian berkualitas tinggi untuk hasil optimal.', 0, 100)); ?>...</p>
                            
                            <!-- Price & Status -->
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div class="price-badge shadow-sm">
                                    <i class="bi bi-currency-rupee me-1"></i>
                                    <?php echo number_format($alat['harga_sewa_per_hari'], 0, ',', '.'); ?><small class="ms-1">/hari</small>
                                </div>
                                <span class="badge bg-<?php echo $alat['kondisi']=='Baik' ? 'success' : 'warning'; ?> fs-6">
                                    <?php echo $alat['kondisi'] ?? 'Baik'; ?>
                                </span>
                            </div>
                            
                            <!-- Action Button -->
                            <button class="btn btn-shopee w-100 py-3 fw-bold shadow-lg glow-btn pinjam-btn" data-id="<?php echo $alat['id']; ?>" data-nama="<?php echo htmlspecialchars($alat['nama']); ?>" data-harga="<?php echo $alat['harga_sewa_per_hari']; ?>">
                                <i class="bi bi-calendar-plus fs-5 me-2"></i>
                                PINJAM SEKARANG
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php if (empty($alat_list)): ?>
                <div class="col-12 text-center py-8">
                    <i class="bi bi-search fs-1 text-muted mb-4 d-block"></i>
                    <h4 class="text-white-50 mb-3">Tidak ada alat ditemukan</h4>
                    <p class="text-muted lead mb-4">Coba ubah kata kunci atau kategori</p>
                    <button class="btn btn-shopee px-5" onclick="location.reload()">
                        <i class="bi bi-arrow-clockwise me-2"></i>Refresh
                    </button>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Alat pagination" class="mt-8">
                <ul class="pagination justify-content-center gap-2">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link pagination-btn" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&kategori=<?php echo urlencode($kategori); ?>">
                                <i class="bi bi-chevron-left"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link pagination-btn <?php echo $i == $page ? 'bg-shopee text-white' : ''; ?>" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&kategori=<?php echo urlencode($kategori); ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link pagination-btn" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&kategori=<?php echo urlencode($kategori); ?>">
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
        
        <!-- Booking Modal - Premium -->
        <div class="modal fade" id="bookingModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-0 bg-shopee-gradient text-white">
                        <div class="d-flex align-items-center">
                            <div class="me-3 p-2 rounded-circle bg-white bg-opacity-20">
                                <i class="bi bi-calendar-check-fill fs-4"></i>
                            </div>
                            <div>
                                <h5 class="mb-0 fw-bold" id="modal_alat_title">Booking Alat</h5>
                                <small class="opacity-75" id="modal_alat_subtitle">Pilih tanggal pinjam</small>
                            </div>
                        </div>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" id="bookingForm">
                        <div class="modal-body p-4">
                            <input type="hidden" name="action" value="pinjam">
                            <input type="hidden" name="alat_id" id="modal_alat_id">
                            <input type="hidden" id="modal_harga">
                            
                            <div class="mb-4 text-center pb-4 border-bottom">
                                <div class="h4 fw-bold text-shopee mb-1" id="modal_alat_nama">Pilih alat...</div>
                                <small class="text-muted">Harga/hari <span class="badge bg-success fs-6 px-3 py-1 shadow-sm" id="modal_harga_display">Rp 0</span></small>
                            </div>
                            
                            <div class="row g-4 mb-4">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-dark">📅 Tanggal Mulai</label>
                                    <input type="date" name="tgl_mulai" class="form-control glass-input shadow-sm" required min="<?php echo date('Y-m-d'); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-dark">📅 Tanggal Selesai</label>
                                    <input type="date" name="tgl_selesai" class="form-control glass-input shadow-sm" required min="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                            
                            <div class="preview-section bg-light rounded-4 p-4 shadow-sm border" id="preview">
                                <div class="row text-center g-3">
                                    <div class="col-md-4 border-end">
                                        <div class="h6 text-muted mb-1">Hari Pinjam</div>
                                        <div class="h4 fw-bold text-shopee mb-0" id="preview_hari">0</div>
                                    </div>
                                    <div class="col-md-4 border-end">
                                        <div class="h6 text-muted mb-1">Harga/hari</div>
                                        <div class="h4 fw-bold text-success mb-0" id="preview_harga">Rp 0</div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="h6 text-muted mb-1">Total Bayar</div>
                                        <div class="h2 fw-bold text-primary mb-0" id="preview_total">Rp 0</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="alert alert-info mt-4 shadow-sm" role="alert">
                                <i class="bi bi-info-circle me-2"></i>
                                <small>Biaya dihitung otomatis. Stok dikurangi saat booking. Admin approve <strong>max 24 jam</strong>.</small>
                            </div>
                        </div>
                        <div class="modal-footer border-0 p-4">
                            <button type="button" class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">
                                <i class="bi bi-x me-2"></i>Batal
                            </button>
                            <button type="submit" class="btn btn-shopee px-5 py-2 fw-bold shadow-lg" id="submitBtn">
                                <i class="bi bi-check-circle-fill me-2"></i>
                                Konfirmasi Booking <span class="badge bg-light text-dark ms-2" id="total_biaya">Rp 0</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/realtime-sync.js"></script>
    <script>
        // Live search + kategori + pagination
        let currentPage = <?php echo $page; ?>;
        let searchTerm = '<?php echo addslashes($search); ?>';
        let kategoriId = '<?php echo addslashes($kategori); ?>';
        
        // Search
        document.getElementById('searchInput').addEventListener('input', debounce(function(e) {
            searchTerm = e.target.value;
            loadAlat(1);
        }, 300));
        
        // Kategori filter - Fixed working
        document.querySelectorAll('[data-kat]').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelectorAll('[data-kat]').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                kategoriId = this.dataset.kat || '';
                loadAlat(1);
            });
        });
        
        // Load alat AJAX - Fixed working
        async function loadAlat(page = 1) {
            const params = new URLSearchParams({
                page: page,
                search: searchTerm,
                kategori: kategoriId
            });
            const url = `pinjam.php?${params}`;
            
            try {
                const response = await fetch(url);
                if (!response.ok) throw new Error('Network error');
                
                const html = await response.text();
                const parser = new DOMParser();
                const newDoc = parser.parseFromString(html, 'text/html');
                const newGrid = newDoc.querySelector('#alatGrid');
                if (newGrid) {
                    document.querySelector('#alatGrid').innerHTML = newGrid.innerHTML;
                    initPinjamButtons();
                    // Reinit kategori buttons
                    document.querySelectorAll('[data-kat]').forEach(btn => {
                        btn.classList.toggle('active', btn.dataset.kat === kategoriId);
                    });
                }
            } catch (e) {
                console.error('Load failed:', e);
                alert('Gagal memuat data. Refresh halaman.');
            }
        }
        
        // Pinjam buttons - event delegation
        function initPinjamButtons() {
            document.removeEventListener('click', handlePinjamClick);
            document.addEventListener('click', handlePinjamClick);
        }
        
        function handlePinjamClick(e) {
            if (e.target.closest('.pinjam-btn')) {
                e.preventDefault();
                const btn = e.target.closest('.pinjam-btn');
                if (btn.disabled) return;
                
                document.getElementById('modal_alat_id').value = btn.dataset.id;
                document.getElementById('modal_alat_nama').textContent = btn.dataset.nama;
                document.getElementById('modal_harga').value = btn.dataset.harga;
                document.getElementById('modal_harga_display').textContent = 'Rp ' + parseFloat(btn.dataset.harga).toLocaleString('id-ID');
                document.getElementById('modal_alat_title').textContent = btn.dataset.nama;
                
                const modal = new bootstrap.Modal(document.getElementById('bookingModal'));
                modal.show();
            }
        }
        
        // Modal calculator
        document.getElementById('bookingModal').addEventListener('shown.bs.modal', function() {
            const inputs = ['tgl_mulai', 'tgl_selesai'].map(id => document.querySelector(`[name="${id}"]`));
            inputs.forEach(input => input.addEventListener('change', calculatePreview));
            calculatePreview(); // Initial
        });
        
        function calculatePreview() {
            const mulai = document.querySelector('[name="tgl_mulai"]').value;
            const selesai = document.querySelector('[name="tgl_selesai"]').value;
            const harga = parseFloat(document.getElementById('modal_harga').value) || 0;
            
            if (mulai && selesai && new Date(selesai) >= new Date(mulai)) {
                const hari = Math.ceil((new Date(selesai) - new Date(mulai)) / (1000 * 60 * 60 * 24)) + 1;
                const total = Math.round(hari * harga);
                
                document.getElementById('preview_hari').textContent = hari;
                document.getElementById('preview_harga').textContent = 'Rp ' + harga.toLocaleString('id-ID');
                document.getElementById('preview_total').textContent = 'Rp ' + total.toLocaleString('id-ID');
                document.getElementById('total_biaya').textContent = total.toLocaleString('id-ID');
            } else {
                document.getElementById('preview_hari').textContent = '0';
                document.getElementById('preview_harga').textContent = 'Rp 0';
                document.getElementById('preview_total').textContent = 'Rp 0';
                document.getElementById('total_biaya').textContent = '0';
            }
        }
        
        // Utils
        function debounce(func, delay) {
            let timeout;
            return function(...args) {
                clearTimeout(timeout);
                timeout = setTimeout(() => func.apply(this, args), delay);
            };
        }
        
        initPinjamButtons();
    </script>
</body>
</html>
