<?php
// user/dashboard.php - Clean simple dashboard
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'user') {
    redirect('../index.php');
}

$user_id = $_SESSION['user_id'];

// Stats
$stmt = $pdo->prepare("SELECT COUNT(*) FROM peminjaman WHERE user_id = ?");
$stmt->execute([$user_id]);
$total_booking = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM peminjaman WHERE user_id = ? AND status = 'booking'");
$stmt->execute([$user_id]);
$pending = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Alat Tani</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
    <style>
        body { 
            position: relative; 
            overflow-x: hidden;
        }
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 80%, rgba(238,77,45,0.15) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255,107,53,0.12) 0%, transparent 50%);
            z-index: -1;
            animation: bgFloat 25s ease-in-out infinite;
        }
        @keyframes bgFloat {
            0%, 100% { transform: scale(1) rotate(0deg); }
            33% { transform: scale(1.02) rotate(120deg); }
            66% { transform: scale(1.01) rotate(240deg); }
        }
        .stat-card {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(25px);
            border: 1px solid rgba(255,255,255,0.9);
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 50px rgba(238,77,45,0.2);
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4" style="background: linear-gradient(135deg, #EE4D2D, #FF6B35); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">
                <i class="bi bi-person-circle me-2"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
            </h4>
            <a href="dashboard.php" class="nav-item active">
                <i class="bi bi-house-door nav-icon"></i> Dashboard
            </a>
            <a href="pinjam.php" class="nav-item">
                <i class="bi bi-calendar-plus nav-icon"></i> Pinjam Alat
            </a>
            <a href="riwayat.php" class="nav-item">
                <i class="bi bi-clock-history nav-icon"></i> Riwayat
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content p-4">
        <div class="header mb-5">
            <h1 class="text-white mb-2"><i class="bi bi-house-door me-2"></i>Dashboard</h1>
            <p class="text-white-50 mb-0">Kelola peminjaman alat tani</p>
        </div>
        
        <!-- Stats -->
        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="stat-card h-100 p-4 text-center rounded-4 shadow-lg">
                    <i class="bi bi-calendar-check fs-1 text-warning mb-3"></i>
                    <h2 class="fw-bold mb-1"><?php echo $total_booking; ?></h2>
                    <p class="text-muted fs-5 mb-0">Total Peminjaman</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card h-100 p-4 text-center rounded-4 shadow-lg">
                    <i class="bi bi-hourglass-split fs-1 text-info mb-3"></i>
                    <h2 class="fw-bold mb-1"><?php echo $pending; ?></h2>
                    <p class="text-muted fs-5 mb-0">Pending Approval</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card h-100 p-4 text-center rounded-4 shadow-lg">
                    <i class="bi bi-check-circle fs-1 text-success mb-3"></i>
                    <h2 class="fw-bold mb-1"><?php echo $total_booking - $pending; ?></h2>
                    <p class="text-muted fs-5 mb-0">Approved</p>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="stat-card p-5 rounded-4 shadow-lg text-center position-relative overflow-hidden">
                    <div class="bg-shopee rounded-circle position-absolute top-50 start-50 translate-middle" style="width: 120px; height: 120px; opacity: 0.1; font-size: 3rem; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-calendar-plus"></i>
                    </div>
                    <i class="bi bi-calendar-plus fs-1 text-shopee mb-4 d-block"></i>
                    <h2 class="fw-bold mb-3 text-shopee">Pinjam Alat Pertanian</h2>
                    <p class="lead text-muted mb-4">Stok terupdate real-time - booking mudah</p>
                    <a href="pinjam.php" class="btn btn-shopee px-5 py-3 fs-5">
                        <i class="bi bi-arrow-right me-2"></i>Pinjam Sekarang
                    </a>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="stat-card h-100 p-4 rounded-4 shadow-lg">
                    <h5 class="fw-bold mb-4 text-shopee"><i class="bi bi-clock-history me-2"></i>Riwayat Terbaru</h5>
                    <?php
                    $recent = $pdo->prepare("SELECT p.*, a.nama FROM peminjaman p JOIN alat a ON p.alat_id = a.id WHERE p.user_id = ? ORDER BY p.created_at DESC LIMIT 5");
                    $recent->execute([$user_id]);
                    $recent_history = $recent->fetchAll();
                    ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($recent_history as $h): ?>
                            <a href="riwayat.php" class="list-group-item list-group-item-action py-3 border-0">
                                <div class="d-flex w-100 justify-content-between">
                                    <small class="fw-semibold"><?php echo htmlspecialchars($h['nama']); ?></small>
                                    <span class="badge bg-<?php echo $h['status']=='dikembalikan' ? 'success' : ($h['status']=='dipinjam' ? 'warning' : 'info'); ?>">
                                        <?php echo ucfirst($h['status']); ?>
                                    </span>
                                </div>
                                <div class="text-muted small"><?php echo date('d M Y', strtotime($h['created_at'])); ?></div>
                            </a>
                        <?php endforeach; ?>
                        <?php if (empty($recent_history)): ?>
                            <div class="text-center py-4 text-muted">
                                <i class="bi bi-inbox fs-3 mb-2 d-block"></i>
                                Belum ada riwayat
                            </div>
                        <?php endif; ?>
                    </div>
                    <a href="riwayat.php" class="btn btn-outline-shopee w-100 mt-3">Lihat Semua Riwayat</a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

