<?php
// API: Real-time alat stok for user/pinjam.php
require_once '../config/koneksi.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

try {
$stmt = $pdo->query("
        SELECT id, nama, kategori_id, COALESCE(kondisi, 'Baik') as kondisi, stok, harga_sewa_per_hari, deskripsi 
        FROM alat 
        WHERE stok > 0 
        ORDER BY nama
    ");
    
    $alat = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($alat);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>

