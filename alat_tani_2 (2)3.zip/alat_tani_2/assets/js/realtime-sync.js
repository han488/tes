// Real-Time Stok Sync for Alat Tani
// Auto-refresh alat list every 10s for live approve/return updates

let refreshInterval;

document.addEventListener('DOMContentLoaded', function() {
    initRealtimeSync();
});

function initRealtimeSync() {
    // Target pages with alat list
    if (document.querySelector('.alat-sync') || document.querySelector('#alat-grid')) {
        console.log('Real-time sync activated');
        startPolling();
        
        // Stop when page unload
        window.addEventListener('beforeunload', () => stopPolling());
    }
}

function startPolling() {
    refreshStok();
    refreshInterval = setInterval(refreshStok, 10000); // 10s
}

function stopPolling() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

async function refreshStok() {
    try {
        const response = await fetch('../api/alat-stok.php');
        
        if (!response.ok) throw new Error('API error');
        
        const alatList = await response.json();
        updateAlatList(alatList);
        
        console.log('Stok synced:', alatList.length, 'items');
    } catch (error) {
        console.error('Sync failed:', error);
    }
}

function updateAlatList(alatList) {
const container = document.querySelector('.alat-sync') || document.querySelector('.row.g-4.alat-sync');
    
    if (!container) return;
    
    alatList.forEach(alat => {
        const cardCol = Array.from(container.children).find(col => 
            col.querySelector('.pinjam-btn[data-id="' + alat.id + '"]')
        );
        
        if (cardCol) {
            const stokBadge = cardCol.querySelector('.badge.bg-primary');
            if (stokBadge) {
                stokBadge.textContent = 'Stok: ' + alat.stok;
            }
            
            const btn = cardCol.querySelector('.pinjam-btn');
            if (alat.stok === 0) {
                cardCol.style.opacity = '0.6';
                btn.disabled = true;
                btn.innerHTML = '<i class="bi bi-x-circle me-2"></i>HABIS';
                btn.title = 'Stok habis';
            } else {
                cardCol.style.opacity = '1';
                btn.disabled = false;
                if (btn.innerHTML.includes('HABIS')) {
                    btn.innerHTML = '<i class="bi bi-calendar-plus me-2"></i>PINJAM SEKARANG';
                }
                btn.title = 'Pinjam alat ini';
            }
        }
    });
}

// WebSocket future
function connectWebSocket() {
    if (typeof WebSocket === 'undefined') return;
    
    const ws = new WebSocket('ws://localhost:8080');
    ws.onmessage = function(event) {
        const data = JSON.parse(event.data);
        if (data.type === 'stok_update') {
            stopPolling();
            updateAlatList([data.alat]);
        }
    };
}



