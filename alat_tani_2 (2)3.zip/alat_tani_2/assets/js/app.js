// Global app JS for Alat Tani
document.addEventListener('DOMContentLoaded', function() {
    // Custom center modal logout confirm
    document.querySelectorAll('a[href*="logout"]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Create modal
            const modalId = 'logoutConfirmModal';
            let modal = document.getElementById(modalId);
            if (!modal) {
                modal = document.createElement('div');
                modal.innerHTML = `
                    <div class="modal fade" id="${modalId}" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content border-0 shadow-lg" style="border-radius: 20px;">
                                <div class="modal-header border-0 bg-danger bg-opacity-90 text-white" style="border-radius: 20px 20px 0 0;">
                                    <i class="bi bi-exclamation-triangle-fill fs-3 me-2"></i>
                                    <h5 class="modal-title fw-bold mb-0">Konfirmasi Logout</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body text-center py-5">
                                    <div class="mb-4">
                                        <div class="bg-warning bg-opacity-20 rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-3" style="width: 80px; height: 80px;">
                                            <i class="bi bi-box-arrow-right fs-1 text-warning"></i>
                                        </div>
                                    </div>
                                    <h4 class="fw-bold text-dark mb-3">Bawahan, yakin mau log out?</h4>
                                    <p class="text-muted mb-0">Semua data session akan hilang dan Anda akan dialihkan ke halaman login.</p>
                                </div>
                                <div class="modal-footer border-0 justify-content-center">
                                    <button type="button" class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">
                                        <i class="bi bi-x-circle me-1"></i>Batal
                                    </button>
                                    <a href="${this.href}" class="btn btn-danger px-5 fw-bold">
                                        <i class="bi bi-check2-circle me-1"></i>Ya, Logout
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
            }
            
            const bootstrapModal = new bootstrap.Modal(document.getElementById(modalId));
            bootstrapModal.show();
        });
    });
    
    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            if (!this.href.includes('logout')) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});

