<?php
// admin/alat.php - CRUD with glassmorphism UI
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    redirect('../index.php');
}

$message = '';

if ($_POST) {
    if (isset($_POST['add'])) {
        $nama = trim($_POST['nama']);
        $kategori_id = (int)$_POST['kategori_id'] ?: null;
        $stok = (int)$_POST['stok'];
        $harga = (float)str_replace(',', '.', $_POST['harga']);
        $deskripsi = trim($_POST['deskripsi']);
        
$foto = null;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            $foto_ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
            if (in_array($foto_ext, ['jpg','jpeg','png','webp'])) {
                $foto_name = 'alat_' . time() . '.' . $foto_ext;
                $foto_path = '../uploads/' . $foto_name;
                if (move_uploaded_file($_FILES['foto']['tmp_name'], $foto_path)) {
                    $foto = $foto_name;
                }
            }
        }
        
        $stmt = $pdo->prepare("INSERT INTO alat (nama, kategori_id, foto, stok, harga_sewa_per_hari, deskripsi) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nama, $kategori_id, $foto, $stok, $harga, $deskripsi]);
        $message = '<div class="alert alert-success shadow-lg">✅ Alat baru ditambahkan!</div>';

    } elseif (isset($_POST['edit'])) {
            $id = (int)$_POST['id'];
            $nama = trim($_POST['nama']);
            $kategori_id = (int)$_POST['kategori_id'] ?: null;
            $stok = (int)$_POST['stok'];
            $harga = (float)str_replace(',', '.', $_POST['harga']);
            $deskripsi = trim($_POST['deskripsi']);
            
            $stmt = $pdo->prepare("SELECT foto FROM alat WHERE id = ?");
            $stmt->execute([$id]);
            $current_foto = $stmt->fetchColumn();
            
            $foto = $current_foto;
            if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
                if ($current_foto && file_exists('../uploads/' . $current_foto)) {
                    unlink('../uploads/' . $current_foto);
                }
                $foto_ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
                if (in_array($foto_ext, ['jpg','jpeg','png','webp'])) {
                    $foto_name = 'alat_' . time() . '.' . $foto_ext;
                    $foto_path = '../uploads/' . $foto_name;
                    if (move_uploaded_file($_FILES['foto']['tmp_name'], $foto_path)) {
                        $foto = $foto_name;
                    }
                }
            }
            
            $stmt = $pdo->prepare("UPDATE alat SET nama=?, kategori_id=?, foto=?, stok=?, harga_sewa_per_hari=?, deskripsi=? WHERE id=?");
            $stmt->execute([$nama, $kategori_id, $foto, $stok, $harga, $deskripsi, $id]);
            $message = '<div class="alert alert-success shadow-lg">✅ Alat diupdate!</div>';

    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("SELECT foto FROM alat WHERE id=?");
        $stmt->execute([$id]);
        $foto = $stmt->fetchColumn();
        if ($foto && file_exists('../uploads/' . $foto)) {
            unlink('../uploads/' . $foto);
        }
        $stmt = $pdo->prepare("DELETE FROM alat WHERE id=?");
        if ($stmt->execute([$id])) {
            $message = '<div class="alert alert-success shadow-lg">🗑️ Alat dihapus!</div>';
        }
    }
}

$alat_list = $pdo->query("SELECT a.*, k.nama as kat_nama FROM alat a LEFT JOIN kategori k ON a.kategori_id = k.id ORDER BY a.id DESC")->fetchAll();

$kategori_list = $pdo->query("SELECT * FROM kategori")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Alat - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/shopee.css" rel="stylesheet">
    <link href="../assets/css/shopee-profile.css" rel="stylesheet">

</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4">Admin Panel</h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Kelola Booking
            </a>
            <a href="alat.php" class="nav-item active">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
            <a href="users.php" class="nav-item">
                <i class="bi bi-people nav-icon"></i> Users
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-tools"></i> Manajemen Alat</h1>
            <div class="user-profile">
                <div class="profile-avatar">A</div>
                <span class="text-white">Halo, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <?php echo $message ?? ''; ?>
        
        <div class="mb-4">
            <button class="btn btn-warning shadow-lg px-4 py-2 text-white fw-bold" data-bs-toggle="modal" data-bs-target="#addModal" style="background: linear-gradient(135deg, #EE4D2D 0%, #FF6B35 100%); border: none;">
                <i class="bi bi-plus-circle me-2"></i> Tambah Alat
            </button>
        </div>

        
        <div class="shopee-card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="bg-shopee text-white">
                            <tr>
                                <th><i class="bi bi-image me-1"></i>Foto</th>
                                <th><i class="bi bi-tag me-1"></i>Nama</th>
                                <th><i class="bi bi-folder me-1"></i>Kategori</th>
                                <th><i class="bi bi-box-seam me-1"></i>Stok</th>
                                <th><i class="bi bi-currency-rupiah me-1"></i>Harga/Hari</th>
                                <th><i class="bi bi-gear me-1"></i>Aksi</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($alat_list as $alat): ?>
                            <tr>
                                <td>
                                    <?php if ($alat['foto']): ?>
                                    <img src="../uploads/<?php echo htmlspecialchars($alat['foto']); ?>" class="alat-img-table img-thumbnail rounded shadow">

                                    <?php else: ?>
                                        <div class="bg-secondary-subtle rounded p-3 d-flex align-items-center justify-content-center" style="width:50px;height:50px;">
                                            <i class="bi bi-image fs-5 opacity-50"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-semibold" data-nama="<?php echo htmlspecialchars($alat['nama']); ?>"><?php echo htmlspecialchars($alat['nama']); ?></td>
                                <td><?php echo htmlspecialchars($alat['kat_nama'] ?? 'Tidak ada'); ?></td>
                                <td><span class="badge bg-<?php echo $alat['stok'] > 0 ? 'success' : 'danger'; ?> fs-6"><?php echo $alat['stok']; ?></span></td>
                                <td><strong>Rp <?php echo number_format($alat['harga_sewa_per_hari'], 0, ',', '.'); ?></strong></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-warning btn-sm edit-btn" data-bs-toggle="modal" data-bs-target="#editModal" data-id="<?php echo $alat['id']; ?>" data-nama="<?php echo htmlspecialchars($alat['nama']); ?>" data-kat="<?php echo htmlspecialchars($alat['kat_nama'] ?? ''); ?>" data-stok="<?php echo $alat['stok']; ?>" data-harga="<?php echo $alat['harga_sewa_per_hari']; ?>" data-foto="<?php echo htmlspecialchars($alat['foto'] ?? ''); ?>">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Hapus <?php echo addslashes($alat['nama']); ?>?')">
                                            <input type="hidden" name="id" value="<?php echo $alat['id']; ?>">
                                            <button type="submit" name="delete" class="btn btn-danger btn-sm">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($alat_list)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-white-50">
                                    <i class="bi bi-tools fs-1 opacity-50 mb-3 d-block"></i>
                                    <h5>Belum ada alat</h5>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Add Modal -->
        <div class="modal fade" id="addModal">
            <div class="modal-dialog modal-lg">
                <div class="modal-content" style="background: rgba(255,255,255,0.9); backdrop-filter: blur(10px);">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="modal-header border-0">
                            <h5 class="modal-title fw-bold">Tambah Alat Baru</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Nama Alat *</label>
                                    <input type="text" class="form-control" name="nama" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Kategori</label>
                                    <select class="form-select" name="kategori_id">
                                        <option value="">-- Pilih --</option>
                                        <?php foreach ($kategori_list as $kat): ?>
                                        <option value="<?php echo $kat['id']; ?>"><?php echo htmlspecialchars($kat['nama']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Foto</label>
                                    <input type="file" class="form-control" name="foto" accept="image/*">
                                    <small class="text-muted">JPG, PNG, WebP max 5MB</small>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Stok *</label>
                                    <input type="number" class="form-control" name="stok" min="0" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Harga/Hari (Rp) *</label>
                                    <input type="text" class="form-control" name="harga" placeholder="50000" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Deskripsi</label>
                                    <textarea class="form-control" name="deskripsi" rows="4" placeholder="Deskripsi alat..."></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" name="add" class="btn btn-warning px-4 text-white fw-bold" style="background: linear-gradient(135deg, #EE4D2D 0%, #FF6B35 100%); border: none;">
                                <i class="bi bi-plus-circle"></i> Tambah Alat
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        
        <!-- Edit Modal (similar structure, populated by JS) -->
        <div class="modal fade" id="editModal">
            <div class="modal-dialog modal-lg">
                <div class="modal-content" style="background: rgba(255,255,255,0.9); backdrop-filter: blur(10px);">
                    <form method="POST" enctype="multipart/form-data" id="editForm">
                        <div class="modal-header border-0">
                            <h5 class="modal-title fw-bold">Edit Alat</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" id="edit_id">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Nama Alat *</label>
                                    <input type="text" class="form-control" name="nama" id="edit_nama" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Kategori</label>
                                    <select class="form-select" name="kategori_id" id="edit_kategori">
                                        <option value="">-- Pilih --</option>
                                        <?php foreach ($kategori_list as $kat): ?>
                                        <option value="<?php echo $kat['id']; ?>"><?php echo htmlspecialchars($kat['nama']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Foto Baru (kosong=keep lama)</label>
                                    <input type="file" class="form-control" name="foto" id="edit_foto" accept="image/*">
                                    <div id="current_foto_preview" class="mt-2"></div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Stok *</label>
                                    <input type="number" class="form-control" name="stok" id="edit_stok" min="0" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Harga/Hari (Rp) *</label>
                                    <input type="text" class="form-control" name="harga" id="edit_harga" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Deskripsi</label>
                                    <textarea class="form-control" name="deskripsi" id="edit_deskripsi" rows="4"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-0">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" name="edit" class="btn btn-warning px-4 text-white fw-bold" style="background: linear-gradient(135deg, #EE4D2D 0%, #FF6B35 100%); border: none;">
                                <i class="bi bi-check-circle"></i> Update Alat
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('edit_id').value = this.dataset.id;
                document.getElementById('edit_nama').value = this.dataset.nama || '';
                document.getElementById('edit_stok').value = this.dataset.stok || 0;
                document.getElementById('edit_harga').value = parseFloat(this.dataset.harga || 0).toLocaleString('id-ID');
                
                // Kategori
                const kat = this.dataset.kat;
                const select = document.getElementById('edit_kategori');
                for (let option of select.options) {
                    if (option.text.trim() === kat.trim()) {
                        option.selected = true;
                        break;
                    }
                }
                
                // Foto preview
                const foto = this.dataset.foto;
                const preview = document.getElementById('current_foto_preview');
                if (foto) {
                    preview.innerHTML = `<div class="alert alert-info p-2"><small>Foto saat ini: <img src="../uploads/${foto}" width="60" class="rounded shadow me-2"> <strong>${foto}</strong></small></div>`;
                } else {
                    preview.innerHTML = '<div class="alert alert-secondary p-2"><small>Tidak ada foto</small></div>';
                }
            });
        });
    </script>
</body>
</html>

