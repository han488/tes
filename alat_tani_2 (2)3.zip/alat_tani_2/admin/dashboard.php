
<?php
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    redirect('../index.php');
}

$total_alat = $pdo->query("SELECT COUNT(*) FROM alat")->fetchColumn();
$total_kategori = $pdo->query("SELECT COUNT(*) FROM kategori")->fetchColumn();
$total_booking = $pdo->query("SELECT COUNT(*) FROM peminjaman WHERE status = 'booking'")->fetchColumn();
$total_dipinjam = $pdo->query("SELECT COUNT(*) FROM peminjaman WHERE status = 'dipinjam'")->fetchColumn();
$total_pendapatan = $pdo->query("SELECT SUM(total_biaya + COALESCE(denda, 0)) FROM peminjaman WHERE status = 'dikembalikan'")->fetchColumn() ?: 0;
$total_peminjaman_bulanan = $pdo->query("SELECT COUNT(*) FROM peminjaman WHERE MONTH(created_at) = MONTH(CURDATE())")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Alat Tani</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">

</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4">Admin Panel</h4>
            <a href="dashboard.php" class="nav-item active">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Kelola Booking
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
<a href="users.php" class="nav-item">
                <i class="bi bi-people nav-icon"></i> Users
            </a>
            <a href="grafik-peminjaman.php" class="nav-item">
                <i class="bi bi-graph-up nav-icon"></i> Grafik
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>

        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0">Dashboard Admin</h1>
            <div class="user-profile">
                <div class="profile-avatar">A</div>
                <span class="text-white">Halo, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <div class="notification-icon">🔔</div>
            </div>
        </div>
        
        <div class="row g-4 mb-5">
            <div class="col-xl-3 col-md-6">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">🛠️</div>
                    <div class="h5 fw-bold text-shopee mb-1"><?php echo $total_alat; ?></div>
                    <div class="text-muted">Total Alat</div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">🏷️</div>
                    <div class="h5 fw-bold text-shopee mb-1"><?php echo $total_kategori; ?></div>
                    <div class="text-muted">Kategori</div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">📅</div>
                    <div class="h5 fw-bold text-shopee mb-1"><?php echo $total_booking; ?></div>
                    <div class="text-muted">Booking</div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">👥</div>
                    <div class="h5 fw-bold text-shopee mb-1"><?php echo $total_dipinjam; ?></div>
                    <div class="text-muted">Dipinjam</div>
                </div>
            </div>
        </div>

        
        <div class="row g-4 mb-4">
            <div class="col-lg-4">
                <a href="grafik-peminjaman.php" class="text-decoration-none">
                    <div class="shopee-card h-100 p-4 text-center cursor-pointer hover-shopee">
                        <div class="mb-3" style="font-size: 2.5rem;">📊</div>
                        <div class="h4 fw-bold text-shopee mb-1">Grafik</div>
                        <div class="text-muted">Peminjaman bulanan</div>
                    </div>
                </a>
            </div>
            <div class="col-lg-4">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">📅</div>
                    <div class="h4 fw-bold text-shopee mb-1"><?php echo $total_booking; ?></div>
                    <div class="text-muted">Pending Booking</div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">💰</div>
                    <div class="h4 fw-bold text-shopee mb-1">Rp <?php echo number_format($total_pendapatan, 0, ',', '.'); ?></div>
                    <div class="text-muted">Total Pendapatan</div>
                </div>
            </div>
        </div>


    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/app.js"></script>

</body>
</html>

