<?php
// admin/booking.php - Kelola booking with glassmorphism UI
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    redirect('../index.php');
}

$message = '';

if ($_POST) {
    $id = (int)$_POST['id'];
    $action = $_POST['action'];
    
    $stmt = $pdo->prepare("SELECT alat_id, status FROM peminjaman WHERE id = ? FOR UPDATE");
    $stmt->execute([$id]);
    $booking = $stmt->fetch();
    
    if (!$booking) {
        $message = '<div class="alert alert-danger shadow-lg">Peminjaman tidak ditemukan!</div>';
    } else {
        switch ($action) {
            case 'approve':
                if ($booking['status'] === 'booking') {
                    $stmt = $pdo->prepare("UPDATE peminjaman SET status = 'dipinjam' WHERE id = ?");
                    $stmt->execute([$id]);
                    $message = '<div class="alert alert-success shadow-lg">✓ Approved!</div>';
                }
                break;
            case 'reject':
                if ($booking['status'] === 'booking') {
                    $pdo->beginTransaction();
                    try {
                        $stmt = $pdo->prepare("UPDATE peminjaman SET status = 'rejected' WHERE id = ?");
                        $stmt->execute([$id]);
                        $stmt = $pdo->prepare("UPDATE alat SET stok = stok + 1 WHERE id = ?");
                        $stmt->execute([$booking['alat_id']]);
                        $pdo->commit();
                        $message = '<div class="alert alert-warning shadow-lg">✗ Rejected, stok restored!</div>';
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        $message = '<div class="alert alert-danger shadow-lg">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
                    }
                }
                break;
            case 'return':
                if ($booking['status'] === 'dipinjam') {
                    $pdo->beginTransaction();
                    try {
                        $stmt = $pdo->prepare("UPDATE peminjaman SET status = 'dikembalikan', tgl_kembali_actual = CURDATE() WHERE id = ?");
                        $stmt->execute([$id]);
                        $stmt = $pdo->prepare("UPDATE alat SET stok = stok + 1 WHERE id = ?");
                        $stmt->execute([$booking['alat_id']]);
                        $stmt = $pdo->prepare("
                            UPDATE peminjaman p JOIN alat a ON p.alat_id = a.id 
                            SET p.denda = GREATEST(0, DATEDIFF(p.tgl_kembali_actual, p.tgl_selesai) * a.harga_sewa_per_hari * 0.1)
                            WHERE p.id = ?
                        ");
                        $stmt->execute([$id]);
                        $pdo->commit();
                        $denda = $pdo->query("SELECT denda FROM peminjaman WHERE id = $id")->fetchColumn();
                        $message = '<div class="alert alert-success shadow-lg">✅ Returned! Denda Rp' . number_format($denda) . '</div>';
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        $message = '<div class="alert alert-danger shadow-lg">Return failed: ' . htmlspecialchars($e->getMessage()) . '</div>';
                    }
                }
                break;
        }
    }
}

$peminjaman = $pdo->query("
    SELECT p.*, u.username, a.nama as alat_nama, a.stok 
    FROM peminjaman p 
    JOIN users u ON p.user_id = u.id 
    JOIN alat a ON p.alat_id = a.id 
    ORDER BY p.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Booking - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">

</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4">Admin Panel</h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>

            <a href="booking.php" class="nav-item active">
                <i class="bi bi-calendar-check nav-icon"></i> Riwayat Peminjaman
            </a>

            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
            <a href="users.php" class="nav-item">
                <i class="bi bi-people nav-icon"></i> Users
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-calendar-check"></i> Kelola Booking</h1>
            <div class="user-profile">
                <div class="profile-avatar">A</div>
                <span class="text-white">Halo, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <?php echo $message ?? ''; ?>
        
        <div class="row mb-5">
            <div class="col">
                <div class="shopee-card p-4 text-center">
                    <div class="h4 fw-bold text-shopee mb-2"><?php echo count($peminjaman); ?></div>
                    <div class="h6 text-muted mb-0">Peminjaman Aktif</div>
                </div>
            </div>
        </div>

        
        <div class="card" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.2); border-radius: 24px; overflow: hidden;">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Alat</th>
                                <th>Tanggal</th>
                                <th>Biaya</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($peminjaman as $row): ?>
                            <tr class="table-<?php echo $row['status'] === 'booking' ? 'warning' : ($row['status'] === 'dipinjam' ? 'info' : ($row['status'] === 'dikembalikan' ? 'success' : 'secondary')); ?>">
                                <td><strong><?php echo $row['id']; ?></strong></td>
                                <td><?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['alat_nama']); ?> <small>(stok: <?php echo $row['stok']; ?>)</small></td>
                                <td><?php echo date('d/m/Y', strtotime($row['tgl_mulai'])); ?> → <?php echo date('d/m/Y', strtotime($row['tgl_selesai'])); ?></td>
                                <td><strong>Rp <?php echo number_format($row['total_biaya'],0,',','.'); ?></strong></td>
                                <td>
                                    <span class="badge bg-<?php echo $row['status']=='dikembalikan' ? 'success' : ($row['status']=='dipinjam' ? 'info' : ($row['status']=='booking' ? 'warning' : 'secondary')); ?> fs-6 me-2"><?php echo ucfirst($row['status']); ?></span>
                                    <?php if ($row['denda'] > 0): ?>
                                        <br><small class="text-danger fw-bold">Denda: Rp <?php echo number_format($row['denda'],0,',','.'); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if ($row['status'] == 'booking'): ?>
                                        <form method="POST" style="display:inline; margin: 0 2px;" class="btn-group btn-group-sm">
                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                            <button name="action" value="approve" class="btn btn-success" title="Approve">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                            <button name="action" value="reject" class="btn btn-danger" title="Reject">
                                                <i class="bi bi-x-lg"></i>
                                            </button>
                                        </form>
                                    <?php elseif ($row['status'] == 'dipinjam'): ?>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                            <button name="action" value="return" class="btn btn-primary btn-sm" title="Return">
                                                <i class="bi bi-arrow-return-right"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="badge bg-success">✓ Selesai</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($peminjaman)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-white-50">
                                    <i class="bi bi-calendar-x fs-1 opacity-50 mb-3 d-block"></i>
                                    <h5>Belum ada peminjaman</h5>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

