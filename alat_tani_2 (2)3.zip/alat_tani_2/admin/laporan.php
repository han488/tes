<?php
// admin/laporan.php - Monthly Transaction Report with PDF
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    redirect('../index.php');
}

// Get settings
$stmt = $pdo->query("SELECT name, value FROM settings");
$settings = [];
foreach ($stmt->fetchAll() as $row) {
    $settings[$row['name']] = $row['value'];
}

$month = $_GET['bulan'] ?? date('Y-m');
$year = date('Y', strtotime($month));
$month_name = date('F Y', strtotime($month));

// Fetch monthly report
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_transaksi,
        SUM(total_biaya) as total_revenue,
        SUM(denda) as total_denda,
        SUM(total_biaya + denda) as grand_total,
        COUNT(CASE WHEN status = 'dikembalikan' THEN 1 END) as completed,
        COUNT(CASE WHEN status = 'dipinjam' THEN 1 END) as active,
        COUNT(CASE WHEN status = 'booking' THEN 1 END) as pending
    FROM peminjaman 
    WHERE YEAR(created_at) = ? AND MONTH(created_at) = ?
");
$stmt->execute([$year, date('m', strtotime($month))]);
$summary = $stmt->fetch();

// Top users
$month_num = date('m', strtotime($month));
$top_users = $pdo->prepare("
    SELECT u.username, COUNT(p.id) as transaksi, SUM(p.total_biaya + p.denda) as total_spent
    FROM peminjaman p JOIN users u ON p.user_id = u.id
    WHERE YEAR(p.created_at) = ? AND MONTH(p.created_at) = ?
    GROUP BY u.id ORDER BY total_spent DESC LIMIT 5
");
$top_users->execute([$year, $month_num]);
$top_users = $top_users->fetchAll();

// Top alat
$top_alat = $pdo->prepare("
    SELECT a.nama, COUNT(p.id) as dipinjam, SUM(p.total_biaya) as revenue
    FROM peminjaman p JOIN alat a ON p.alat_id = a.id
    WHERE YEAR(p.created_at) = ? AND MONTH(p.created_at) = ?
    GROUP BY a.id ORDER BY revenue DESC LIMIT 5
");
$top_alat->execute([$year, $month_num]);
$top_alat = $top_alat->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Transaksi - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

</head>
<body class="bg-dark text-light">
<link href="../assets/css/shopee.css" rel="stylesheet">
</body>


    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="bi bi-file-earmark-bar-graph me-2 text-primary"></i>Laporan Bulanan</h2>
                    <div>
                        <select id="monthSelect" class="form-select d-inline-block w-auto me-2" onchange="changeMonth()">
                            <?php for ($m = 0; $m < 12; $m++): $mon = date('Y-m', strtotime("-$m months")); ?>
                                <option value="<?php echo $mon; ?>" <?php echo $month == $mon ? 'selected' : ''; ?>>
                                    <?php echo date('F Y', strtotime($mon)); ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                        <a href="laporan_pdf.php?bulan=<?php echo $month; ?>" class="btn btn-success">
                            <i class="bi bi-file-earmark-pdf me-2"></i>Cetak PDF
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="row g-4 mb-5">
<div class="col-lg-3 col-md-6">
                    <div class="card border-0 shadow h-100 text-center" style="background: linear-gradient(135deg, #022c22 0%, #03543f 100%); color: white;">
                        <div class="card-body py-4">
                            <i class="bi bi-receipt fs-1 opacity-75 mb-3 d-block"></i>
                            <h3 class="fw-bold mb-1"><?php echo $summary['total_transaksi'] ?: 0; ?></h3>
                            <p class="mb-0 opacity-90">Total Transaksi</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow h-100 text-center bg-gradient" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
                    <div class="card-body py-4">
                        <i class="bi bi-currency-exchange fs-1 opacity-75 mb-3 d-block"></i>
                        <h3 class="fw-bold mb-1">Rp <?php echo number_format($summary['grand_total'] ?: 0, 0, ',', '.'); ?></h3>
                        <p class="mb-0 opacity-90">Grand Total</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow h-100 text-center bg-gradient" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white;">
                    <div class="card-body py-4">
                        <i class="bi bi-check-circle fs-1 opacity-75 mb-3 d-block"></i>
                        <h3 class="fw-bold mb-1"><?php echo $summary['completed'] ?: 0; ?></h3>
                        <p class="mb-0 opacity-90">Selesai</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow h-100 text-center bg-gradient" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white;">
                    <div class="card-body py-4">
                        <i class="bi bi-clock-history fs-1 opacity-75 mb-3 d-block"></i>
                        <h3 class="fw-bold mb-1"><?php echo $summary['active'] ?: 0; ?></h3>
                        <p class="mb-0 opacity-90">Aktif</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Top Users -->
            <div class="col-lg-6">
                <div class="card shadow border-0">
                    <div class="card-header bg-light">
                        <h6 class="mb-0 fw-semibold"><i class="bi bi-people me-2"></i>User Teraktif</h6>
                    </div>
                    <div class="card-body">
                        <div class="list-group list-group-flush">
                            <?php foreach ($top_users as $user): ?>
                                <div class="list-group-item px-0 border-0">
                                    <div class="row align-items-center">
                                        <div class="col-auto">
                                            <div class="avatar bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:40px;height:40px;font-size:0.875rem;">
                                                <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="fw-semibold"><?php echo htmlspecialchars($user['username']); ?></div>
                                            <small class="text-muted"><?php echo $user['transaksi']; ?> transaksi</small>
                                        </div>
                                        <div class="col-auto text-end">
                                            <div class="fw-bold text-success">Rp <?php echo number_format($user['total_spent'], 0, ',', '.'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <?php if (empty($top_users)): ?>
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-inbox fs-1 mb-3 opacity-50 d-block"></i>
                                    <p class="mb-0">Belum ada data</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Top Alat -->
            <div class="col-lg-6">
                <div class="card shadow border-0">
                    <div class="card-header bg-light">
                        <h6 class="mb-0 fw-semibold"><i class="bi bi-tools me-2"></i>Alat Terpopuler</h6>
                    </div>
                    <div class="card-body">
                        <div class="list-group list-group-flush">
                            <?php foreach ($top_alat as $alat): ?>
                                <div class="list-group-item px-0 border-0">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <div class="fw-semibold"><?php echo htmlspecialchars($alat['nama']); ?></div>
                                            <small class="text-muted"><?php echo $alat['dipinjam']; ?> kali dipinjam</small>
                                        </div>
                                        <div class="col-auto text-end">
                                            <div class="fw-bold text-success">Rp <?php echo number_format($alat['revenue'], 0, ',', '.'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <?php if (empty($top_alat)): ?>
                                <div class="text-center py-4 text-muted">
                                    <i class="bi bi-hammer fs-1 mb-3 opacity-50 d-block"></i>
                                    <p class="mb-0">Belum ada data</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function changeMonth() {
            const month = document.getElementById('monthSelect').value;
            window.location.href = 'laporan.php?bulan=' + month;
        }
    </script>
</body>
</html>
<?php
// Generate PDF (using TCPDF - download tcpdf.org)
if (isset($_GET['pdf'])) {
    $tcpdf_path = dirname(__DIR__) . '/vendor/autoload.php';
    if (!file_exists($tcpdf_path)) {
        $tcpdf_path = dirname(__DIR__) . '/tcpdf/tcpdf.php';
    }
    
    if (file_exists($tcpdf_path)) {
        require_once $tcpdf_path;
    } else {
        die('TCPDF library not found. Please install it via Composer or download from tcpdf.org');
    }
    
    if (!class_exists('TCPDF')) {
        die('TCPDF class not found after loading library');
    }
    
    /** @var \TCPDF $pdf */
    $pdf = new \TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    $pdf->SetCreator('Alat Tani System');
    $pdf->setHeaderFont(Array('helvetica', '', 10));
    $pdf->setFooterFont(Array('helvetica', '', 8));
    $pdf->SetMargins(15, 15, 15);
    $pdf->SetAutoPageBreak(true, 15);
    $pdf->AddPage();
    
    $html = '
    <h1>Laporan Transaksi Bulanan</h1>
    <p><strong>Bulan:</strong> ' . date('F Y', strtotime($month)) . '</p>
    <table border="1" cellpadding="5">
        <tr><th>Metrik</th><th>Jumlah</th></tr>
        <tr><td>Total Transaksi</td><td>' . $summary['total_transaksi'] . '</td></tr>
        <tr><td>Grand Total</td><td>Rp ' . number_format($summary['grand_total'], 0, ',', '.') . '</td></tr>
    </table>';
    
    $pdf->writeHTML($html);
    $pdf->Output('laporan_' . $month . '.pdf', 'D');
    exit;
}
?>
