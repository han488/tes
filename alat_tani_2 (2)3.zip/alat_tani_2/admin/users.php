
<?php
// admin/users.php - CRUD users with glassmorphism UI + Created/Last Login
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    redirect('../index.php');
}

$message = '';

if ($_POST) {
    if (isset($_POST['add'])) {
        $username = trim($_POST['username']);
        $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
        $role = $_POST['role'];
        
        $stmt = $pdo->prepare("INSERT IGNORE INTO users (username, password, role) VALUES (?, ?, ?)");
        if ($stmt->execute([$username, $password, $role])) {
            $message = '<div class="alert alert-success shadow-lg">✅ User ditambahkan!</div>';
        }
    } elseif (isset($_POST['edit'])) {
        $id = (int)$_POST['id'];
        $role = $_POST['role'];
        $password = trim($_POST['password']);
        if ($password) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET role = ?, password = ? WHERE id = ? AND username != 'admin'");
            $stmt->execute([$role, $hash, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ? AND username != 'admin'");
            $stmt->execute([$role, $id]);
        }
        $message = '<div class="alert alert-success shadow-lg">✅ User updated!</div>';
    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND username != 'admin'");
        if ($stmt->execute([$id])) {
            $message = '<div class="alert alert-success shadow-lg">🗑️ User dihapus!</div>';
        }
    }
}

// Add last_login column if not exists
$pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS `last_login` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP");

$stmt = $pdo->query("SELECT * FROM users ORDER BY role DESC, created_at DESC");
$users_list = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Users - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
    <style>
        .text-dark-custom { color: #000 !important; }
        .table-dark-custom th { color: #fff !important; }
        .table-dark-custom td { color: #000 !important; }
    </style>
</head>
<body class="bg-dark">
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4">Admin Panel</h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Kelola Booking
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
            <a href="users.php" class="nav-item active">
                <i class="bi bi-people nav-icon"></i> Users
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-people"></i> Manajemen Users</h1>
            <div class="user-profile">
                <div class="profile-avatar">A</div>
                <span class="text-white">Halo, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <?php echo $message ?? ''; ?>
        
        <div class="mb-4">
            <button class="btn btn-warning shadow-lg px-4 py-2 text-white fw-bold" data-bs-toggle="modal" data-bs-target="#addModal" style="background: linear-gradient(135deg, #EE4D2D 0%, #FF6B35 100%); border: none;">
                <i class="bi bi-plus-circle me-2"></i> Tambah User
            </button>
        </div>

        <div class="card" style="background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.2); border-radius: 24px; overflow: hidden;">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-dark-custom align-middle">
                        <thead class="table-dark-custom">
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Created</th>
                                <th>Last Login</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users_list as $user): ?>
                            <tr>
                                <td class="fw-semibold text-dark-custom"><?php echo $user['id']; ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm rounded-circle bg-<?php echo $user['role']=='admin' ? 'danger' : 'primary'; ?> d-flex align-items-center justify-content-center me-2">
                                            <i class="bi bi-person fs-6 text-white"></i>
                                        </div>
                                        <span class="text-dark-custom"><?php echo htmlspecialchars($user['username']); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $user['role']=='admin' ? 'danger' : 'secondary'; ?> fs-6 px-3 py-2 text-dark-custom"><?php echo ucfirst($user['role']); ?></span>
                                </td>
                                <td class="text-dark-custom"><small><?php echo date('d/m/Y H:i', strtotime($user['created_at'])); ?></small></td>
                                <td class="text-dark-custom"><small><?php echo $user['last_login'] ? date('d/m/Y H:i', strtotime($user['last_login'])) : 'Never'; ?></small></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-warning btn-sm edit-user-btn" data-bs-toggle="modal" data-bs-target="#editModal" 
                                            data-id="<?php echo $user['id']; ?>" data-username="<?php echo htmlspecialchars($user['username']); ?>" data-role="<?php echo $user['role']; ?>">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>
                                        <?php if ($user['username'] != 'admin'): ?>
                                        <form method="POST" style="display:inline" onsubmit="return confirm('Hapus <?php echo htmlspecialchars($user['username']); ?>?')" class="d-inline">
                                            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                            <button type="submit" name="delete" class="btn btn-danger btn-sm">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($users_list)): ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-dark-custom">
                                    <i class="bi bi-people fs-1 opacity-50 mb-3 d-block"></i>
                                    <h5>Belum ada users</h5>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Add User Modal -->
        <div class="modal fade" id="addModal">
            <div class="modal-dialog">
                <div class="modal-content" style="background: rgba(255,255,255,0.95); backdrop-filter: blur(10px);">
                    <form method="POST">
                        <div class="modal-header border-0">
                            <h5 class="modal-title fw-bold text-dark">Tambah User Baru</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label fw-semibold text-dark">Username *</label>
                                <input type="text" class="form-control shadow-sm" name="username" required maxlength="50">
                                <small class="text-muted">Username unik, max 50 karakter</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold text-dark">Password *</label>
                                <input type="password" class="form-control shadow-sm" name="password" required>
                                <small class="text-muted">Akan di-hash otomatis</small>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold text-dark">Role *</label>
                                <select class="form-select shadow-sm" name="role" required>
                                    <option value="">Pilih Role</option>
                                    <option value="user">User (Penyewa)</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer border-0">
                            <button type="button" class="btn btn-outline-secondary shadow-sm" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" name="add" class="btn btn-warning shadow-lg px-4 text-white fw-bold" style="background: linear-gradient(135deg, #EE4D2D 0%, #FF6B35 100%); border: none;">
                                <i class="bi bi-plus-circle me-2"></i>Tambah User
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Edit Modal -->
        <div class="modal fade" id="editModal">
            <div class="modal-dialog">
                <div class="modal-content" style="background: rgba(255,255,255,0.95); backdrop-filter: blur(10px);">
                    <form method="POST" id="editForm">
                        <div class="modal-header border-0">
                            <h5 class="modal-title fw-bold text-dark">Edit User</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id" id="edit_id">
                            <div class="mb-3">
                                <label class="form-label fw-semibold text-dark">Username</label>
                                <input type="text" class="form-control shadow-sm" id="edit_username" readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold text-dark">New Password (kosong=keep lama)</label>
                                <input type="password" class="form-control shadow-sm" name="password" id="edit_password" placeholder="Kosongkan jika tidak ubah">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold text-dark">Role *</label>
                                <select class="form-select shadow-sm" name="role" id="edit_role" required>
                                    <option value="user">User (Penyewa)</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer border-0">
                            <button type="button" class="btn btn-outline-secondary shadow-sm" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" name="edit" class="btn btn-warning shadow-lg px-4">
                                <i class="bi bi-check-circle me-2"></i>Update User
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.querySelectorAll('.edit-user-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('edit_id').value = this.dataset.id;
                document.getElementById('edit_username').value = this.dataset.username;
                document.getElementById('edit_role').value = this.dataset.role;
                document.getElementById('edit_password').value = '';
            });
        });
    </script>
</body>
</html>

