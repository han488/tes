<?php
// admin/alat_fixed.php - Clean CRUD (backup of fixed version)
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../index.php');
    exit;
}

$message = '';

if ($_POST) {
    if (isset($_POST['add'])) {
        $nama = trim($_POST['nama']);
        $kategori_id = !empty($_POST['kategori_id']) ? (int)$_POST['kategori_id'] : null;
        $stok = (int)$_POST['stok'];
        $harga = (float)str_replace(',', '.', $_POST['harga']);
        $deskripsi = trim($_POST['deskripsi']);
        
        $foto = null;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            $foto_ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
            if (in_array($foto_ext, ['jpg','jpeg','png','webp'])) {
                $foto_name = 'alat_' . time() . '.' . $foto_ext;
                $foto_path = '../uploads/' . $foto_name;
                if (move_uploaded_file($_FILES['foto']['tmp_name'], $foto_path)) {
                    $foto = $foto_name;
                }
            }
        }
        
        $kondisi = $_POST['kondisi'] ?? 'Baik';
        $stmt = $pdo->prepare("INSERT INTO alat (nama, kategori_id, kondisi, foto, stok, harga_sewa_per_hari, deskripsi) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $success = $stmt->execute([$nama, $kategori_id, $kondisi, $foto, $stok, $harga, $deskripsi]);
        if ($success) {
            $message = '<div class="alert alert-success shadow-lg">✅ Alat baru ditambahkan!</div>';
        } else {
            $message = '<div class="alert alert-danger">❌ Error menambah alat!</div>';
        }
    } elseif (isset($_POST['edit'])) {
        $id = (int)$_POST['id'];
        $nama = trim($_POST['nama']);
        $kategori_id = !empty($_POST['kategori_id']) ? (int)$_POST['kategori_id'] : null;
        $stok = (int)$_POST['stok'];
        $harga = (float)str_replace(',', '.', $_POST['harga']);
        $deskripsi = trim($_POST['deskripsi']);
        
        $stmt = $pdo->prepare("SELECT foto FROM alat WHERE id = ?");
        $stmt->execute([$id]);
        $current_foto = $stmt->fetchColumn();
        
        $foto = $current_foto;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            if ($current_foto && file_exists('../uploads/' . $current_foto)) {
                unlink('../uploads/' . $current_foto);
            }
            $foto_ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
            if (in_array($foto_ext, ['jpg','jpeg','png','webp'])) {
                $foto_name = 'alat_' . time() . '.' . $foto_ext;
                $foto_path = '../uploads/' . $foto_name;
                if (move_uploaded_file($_FILES['foto']['tmp_name'], $foto_path)) {
                    $foto = $foto_name;
                }
            }
        }
        
        $kondisi = $_POST['kondisi'] ?? 'Baik';
        $stmt = $pdo->prepare("UPDATE alat SET nama=?, kategori_id=?, kondisi=?, foto=?, stok=?, harga_sewa_per_hari=?, deskripsi=? WHERE id=?");
        $success = $stmt->execute([$nama, $kategori_id, $kondisi, $foto, $stok, $harga, $deskripsi, $id]);
        if ($success) {
            $message = '<div class="alert alert-success shadow-lg">✅ Alat diupdate!</div>';
        } else {
            $message = '<div class="alert alert-danger">❌ Error update alat!</div>';
        }
    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("SELECT foto FROM alat WHERE id=?");
        $stmt->execute([$id]);
        $foto = $stmt->fetchColumn();
        if ($foto && file_exists('../uploads/' . $foto)) {
            unlink('../uploads/' . $foto);
        }
        $stmt = $pdo->prepare("DELETE FROM alat WHERE id=?");
        $success = $stmt->execute([$id]);
        if ($success) {
            $message = '<div class="alert alert-success shadow-lg">🗑️ Alat dihapus!</div>';
        } else {
            $message = '<div class="alert alert-danger">❌ Error hapus alat!</div>';
        }
    }
}

$alat_list = $pdo->query("SELECT a.*, k.nama as kat_nama FROM alat a LEFT JOIN kategori k ON a.kategori_id = k.id ORDER BY a.id DESC")->fetchAll();
$kategori_list = $pdo->query("SELECT * FROM kategori")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Alat - Admin Alat Tani</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">

</head>
<body class="bg-gradient">
    <div class="container-fluid py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card shadow-lg border-0">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">
                            <i class="bi bi-tools me-2"></i>
                            Manajemen Alat Pertanian
                            <a href="dashboard.php" class="btn btn-light btn-sm ms-3">
                                <i class="bi bi-house"></i> Dashboard
                            </a>
                        </h4>
                    </div>
                    <?php echo $message ?? ''; ?>
                    <div class="card-body">
                        <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addModal">
                            <i class="bi bi-plus-circle me-2"></i>Tambah Alat Baru
                        </button>
                        
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Foto</th>
                                        <th>Nama</th>
                                        <th>Kategori</th>
                                        <th>Stok</th>
                                        <th>Harga/Hari</th>
                                        <th>Deskripsi</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($alat_list as $alat): ?>
                                    <tr>
                                        <td>
                                            <?php if ($alat['foto']): ?>
                                                <img src="../uploads/<?php echo htmlspecialchars($alat['foto']); ?>" class="alat-img-table rounded">

                                            <?php else: ?>
                                                <span class="badge bg-secondary">No foto</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><strong><?php echo htmlspecialchars($alat['nama']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($alat['kat_nama'] ?? 'N/A'); ?></td>
                                        <td><span class="badge bg-<?php echo $alat['stok'] > 0 ? 'success' : 'danger'; ?>">
                                            <?php echo $alat['stok']; ?>
                                        </span></td>
                                        <td>Rp <?php echo number_format($alat['harga_sewa_per_hari'], 0, ',', '.'); ?></td>
                                        <td><?php echo substr(htmlspecialchars($alat['deskripsi'] ?? ''), 0, 50); ?>...</td>
                                        <td>
                                            <button class="btn btn-sm btn-warning edit-btn" data-bs-toggle="modal" data-bs-target="#editModal" data-id="<?php echo $alat['id']; ?>">
                                                Edit
                                            </button>
                                            <form method="POST" style="display: inline-block;" onsubmit="return confirm('Hapus?')">
                                                <input type="hidden" name="id" value="<?php echo $alat['id']; ?>">
                                                <button type="submit" name="delete" class="btn btn-sm btn-danger">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($alat_list)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <i class="bi bi-inbox fs-1 opacity-50 mb-3 d-block"></i>
                                            Belum ada alat
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal fade" id="addModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h5 class="modal-title">Tambah Alat Baru</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label>Nama</label>
                            <input type="text" name="nama" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Kategori</label>
                            <select name="kategori_id" class="form-control">
                                <option value="">-- Pilih --</option>
                                <?php foreach ($kategori_list as $kat): ?>
                                <option value="<?php echo $kat['id']; ?>"><?php echo htmlspecialchars($kat['nama']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Foto</label>
                            <input type="file" name="foto" class="form-control" accept="image/*">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Stok</label>
                                <input type="number" name="stok" class="form-control" min="0" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Harga (Rp/hari)</label>
                                <input type="text" name="harga" class="form-control" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label>Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Kondisi</label>
                            <select name="kondisi" class="form-control">
                                <option value="Baik">Baik</option>
                                <option value="Cukup">Cukup</option>
                                <option value="Rusak Ringan">Rusak Ringan</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="add" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST" enctype="multipart/form-data" id="editForm">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Alat</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="mb-3">
                            <label>Nama</label>
                            <input type="text" name="nama" id="edit_nama" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Kategori</label>
                            <select name="kategori_id" id="edit_kategori" class="form-control">
                                <option value="">-- Pilih --</option>
                                <?php foreach ($kategori_list as $kat): ?>
                                <option value="<?php echo $kat['id']; ?>"><?php echo htmlspecialchars($kat['nama']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Foto Baru</label>
                            <input type="file" name="foto" id="edit_foto" class="form-control" accept="image/*">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Stok</label>
                                <input type="number" name="stok" id="edit_stok" class="form-control" min="0" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Harga (Rp/hari)</label>
                                <input type="text" name="harga" id="edit_harga" class="form-control" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label>Deskripsi</label>
                            <textarea name="deskripsi" id="edit_deskripsi" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Kondisi</label>
                            <select name="kondisi" id="edit_kondisi" class="form-control">
                                <option value="Baik">Baik</option>
                                <option value="Cukup">Cukup</option>
                                <option value="Rusak Ringan">Rusak Ringan</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="edit" class="btn btn-warning">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Edit modal populate
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('edit_id').value = this.dataset.id;
                document.getElementById('edit_nama').value = this.dataset.nama || '';
                document.getElementById('edit_stok').value = this.dataset.stok || 0;
                document.getElementById('edit_harga').value = new Intl.NumberFormat('id-ID').format(this.dataset.harga || 0);
                // Add more fields as needed
            });
        });
    </script>
</body>
</html>
