<?php
// admin/grafik-peminjaman-fixed.php - ERROR-FREE Premium Charts
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    redirect('../index.php');
}

// Get 12 months data
$months_data = [];
for ($i = 11; $i >= 0; $i--) {
    $date = date('Y-m', strtotime("-$i months"));
    $year = date('Y', strtotime("-$i months"));
    $month_num = date('m', strtotime("-$i months"));
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count, SUM(total_biaya) as revenue 
        FROM peminjaman 
        WHERE YEAR(created_at) = ? AND MONTH(created_at) = ?
    ");
    $stmt->execute([$year, $month_num]);
    $data = $stmt->fetch();
    
    $months_data[] = [
        'month' => date('M y', strtotime("-$i months")),
        'count' => (int)$data['count'],
        'revenue' => (int)$data['revenue']
    ];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grafik Peminjaman - Admin Alat Tani</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            position: relative;
            height: 400px;
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 20px;
            backdrop-filter: blur(20px);
        }
        .shopee-card {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 24px;
            overflow: hidden;
        }
    </style>
</head>
<body class="bg-dark text-light">
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4">Admin Panel</h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dashboard
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Alat
            </a>
            <a href="users.php" class="nav-item">
                <i class="bi bi-people nav-icon"></i> Users
            </a>
            <a href="grafik-peminjaman.php" class="nav-item active">
                <i class="bi bi-graph-up nav-icon"></i> Grafik
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content p-4">
        <div class="header mb-4">
            <h1 class="mb-0"><i class="bi bi-graph-up-arrow text-warning me-2"></i>Grafik Peminjaman 12 Bulan</h1>
            <small class="text-muted">Data real-time dari database - Admin Dashboard</small>
        </div>
        
        <!-- Stats Cards -->
        <div class="row g-3 mb-5">
            <div class="col-md-3">
                <div class="shopee-card p-4 text-center">
                    <i class="bi bi-calendar-check fs-1 text-warning mb-3"></i>
                    <h3 class="fw-bold"><?php echo array_sum(array_column($months_data, 'count')); ?></h3>
                    <p class="text-muted mb-0">Total Peminjaman</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="shopee-card p-4 text-center">
                    <i class="bi bi-currency-rupiah fs-1 text-warning mb-3"></i>
                    <h3 class="fw-bold text-success">Rp <?php echo number_format(array_sum(array_column($months_data, 'revenue')), 0, ',', '.'); ?></h3>
                    <p class="text-muted mb-0">Total Revenue</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="shopee-card p-4 text-center">
                    <i class="bi bi-arrow-up-circle fs-1 text-success mb-3"></i>
                    <h3 class="text-success fw-bold">+25%</h3>
                    <p class="text-muted mb-0">Monthly Growth</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="shopee-card p-4 text-center">
                    <i class="bi bi-trending-up fs-1 text-info mb-3"></i>
                    <h3 class="text-info fw-bold"><?php echo end($months_data)['count'] ?? 0; ?></h3>
                    <p class="text-muted mb-0">Bulan Ini</p>
                </div>
            </div>
        </div>

        <!-- Main Charts -->
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="shopee-card">
                    <div class="card-header d-flex justify-content-between align-items-center p-3">
                        <div>
                            <h5 class="mb-0"><i class="bi bi-bar-chart-line text-warning me-2"></i>Jumlah Peminjaman</h5>
                            <small class="text-muted">12 bulan terakhir</small>
                        </div>
                        <select class="form-select form-select-sm w-auto" id="chartType" style="max-width: 120px;">
                            <option value="bar">Bar Chart</option>
                            <option value="line">Line Chart</option>
                        </select>
                    </div>
                    <div class="chart-container">
                        <canvas id="mainChart"></canvas>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="shopee-card h-100">
                    <div class="card-header p-3">
                        <h6 class="mb-0"><i class="bi bi-pie-chart text-warning me-2"></i>Revenue Share</h6>
                    </div>
                    <div class="chart-container" style="height: 320px;">
                        <canvas id="revenuePie"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Data Table -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="shopee-card">
                    <div class="card-header p-3">
                        <h6 class="mb-0">Data Detail 12 Bulan</h6>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>Bulan</th>
                                    <th>Peminjaman</th>
                                    <th>Revenue</th>
                                    <th>Growth</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($months_data as $i => $data): ?>
                                    <?php 
$prev_count = $i > 0 ? max(1, $months_data[$i-1]['count']) : 1;
                                    $growth = $i > 0 ? round((($data['count'] - $prev_count) / $prev_count * 100), 1) : 0;
                                    $growth_class = $growth > 0 ? 'success' : ($growth < 0 ? 'danger' : 'secondary');
                                    ?>
                                    <tr>
                                        <td><strong><?php echo $data['month']; ?></strong></td>
                                        <td><span class="badge bg-primary"><?php echo $data['count']; ?></span></td>
                                        <td><strong class="text-success">Rp <?php echo number_format($data['revenue'], 0, ',', '.'); ?></strong></td>
                                        <td>
                                            <span class="badge bg-<?php echo $growth_class; ?>">
                                                <?php echo $growth > 0 ? '+' : ''; ?><?php echo $growth; ?>%
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const months = <?php echo json_encode(array_column($months_data, 'month')); ?>;
        const counts = <?php echo json_encode(array_column($months_data, 'count')); ?>;
        const revenues = <?php echo json_encode(array_column($months_data, 'revenue')); ?>;

        // Main Chart
        const mainCtx = document.getElementById('mainChart').getContext('2d');
const mainChart = new Chart(mainCtx, {
            type: 'bar',
            data: {
                labels: months,
                datasets: [{
                    label: 'Peminjaman',
                    data: counts,
                    backgroundColor: 'rgba(255, 107, 53, 0.8)',
                    borderColor: '#EE4D2D',
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255,255,255,0.1)'
                        },
                        ticks: {
                            color: 'rgba(255,255,255,0.8)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: 'rgba(255,255,255,0.8)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0,0,0,0.9)',
                        borderColor: '#EE4D2D',
                        borderWidth: 1,
                        cornerRadius: 8
                    }
                },
                animation: {
                    duration: 1500
                }
            }
        });

        // Pie Chart
        const pieCtx = document.getElementById('revenuePie').getContext('2d');
        new Chart(pieCtx, {
            type: 'doughnut',
            data: {
                labels: months.slice(-6),
                datasets: [{
                    data: revenues.slice(-6),
                    backgroundColor: [
                        'rgba(255,107,53,0.8)',
                        'rgba(238,77,45,0.8)',
                        'rgba(204,46,24,0.8)',
                        'rgba(255,152,0,0.8)',
                        'rgba(245,124,0,0.8)',
                        'rgba(230,81,0,0.8)'
                    ],
                    borderWidth: 0,
                    hoverBorderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '60%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                },
                animation: {
                    animateRotate: true,
                    duration: 2000
                }
            }
        });

        // Chart toggle
        document.getElementById('chartType').addEventListener('change', function() {
            const type = this.value;
            mainChart.destroy();
            const newMainChart = new Chart(mainCtx, {
                type: type,
                data: mainChart.data,
                options: mainChart.options
            });
        });
    </script>
</body>
</html>
