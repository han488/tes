<?php
// config/koneksi.php - Koneksi database menggunakan PDO untuk keamanan
// Asumsi XAMPP: localhost, db 'alat_tani', root/no pass. Ubah jika beda.

$host = 'localhost';
$dbname = 'alat_tani';
$username = 'root';
$password = ''; // Kosong untuk XAMPP default

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage() . "<br>Import dulu db_alat_tani.sql ke phpMyAdmin!");
}

// Fungsi helper untuk protect from SQL injection (PDO sudah prepared)
function query($sql, $params = []) {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

// Fungsi untuk redirect
function redirect($url) {
    header("Location: $url");
    exit;
}

// Start session jika belum
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

