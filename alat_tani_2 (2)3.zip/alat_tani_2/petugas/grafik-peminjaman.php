<?php
// petugas/grafik-peminjaman.php - Copy from admin/ with petugas header
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    redirect('../index.php');
}

$is_petugas = $_SESSION['role'] == 'petugas';

// Get 12 months data
$months_data = [];
for ($i = 11; $i >= 0; $i--) {
    $date = date('Y-m', strtotime("-$i months"));
    $year = date('Y', strtotime("-$i months"));
    $month_num = date('m', strtotime("-$i months"));
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count, SUM(total_biaya) as revenue 
        FROM peminjaman 
        WHERE YEAR(created_at) = ? AND MONTH(created_at) = ?
    ");
    $stmt->execute([$year, $month_num]);
    $data = $stmt->fetch();
    
    $months_data[] = [
        'month' => date('M y', strtotime("-$i months")),
        'count' => (int)$data['count'],
        'revenue' => (int)$data['revenue']
    ];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grafik Peminjaman - <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> Alat Tani</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4"><?php echo $is_petugas ? 'Petugas Panel' : 'Admin Panel'; ?></h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dashboard
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Alat
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Booking
            </a>
            <a href="alat_fixed.php" class="nav-item">
                <i class="bi bi-exclamation-triangle nav-icon"></i> Alat Rusak
            </a>
            <a href="grafik-peminjaman.php" class="nav-item active">
                <i class="bi bi-graph-up nav-icon"></i> Grafik
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content p-4">
        <div class="header mb-4">
            <h1 class="mb-0"><i class="bi bi-graph-up-arrow text-warning me-2"></i>Grafik Peminjaman</h1>
            <small class="text-muted">12 bulan terakhir - <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> Dashboard</small>
        </div>
        
        <!-- Charts and stats same as admin/grafik-peminjaman.php -->
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="shopee-card">
                    <canvas id="mainChart"></canvas>
                </div>
            </div>
            <!-- Other charts -->
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Chart.js config same as admin file
        const months = <?php echo json_encode(array_column($months_data, 'month')); ?>;
        // ... rest same
    </script>
</body>
</html>
