<?php
// petugas/alat_fixed.php - Alat rusak/maintenance panel
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    redirect('../index.php');
}

$is_petugas = $_SESSION['role'] == 'petugas';

$message = '';

// Handle update status
if ($_POST && isset($_POST['update_status'])) {
    $id = (int)$_POST['id'];
    $kondisi = $_POST['kondisi'];
    
    $stmt = $pdo->prepare("UPDATE alat SET kondisi = ? WHERE id = ?");
    if ($stmt->execute([$kondisi, $id])) {
        $message = '<div class="alert alert-success shadow-lg">Status alat diupdate!</div>';
    }
}

// Fetch alat not 'Baik'
$alat_fixed = $pdo->query("SELECT * FROM alat WHERE kondisi != 'Baik' ORDER BY kondisi, id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alat Rusak - <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4"><?php echo $is_petugas ? 'Petugas Panel' : 'Admin Panel'; ?></h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Kelola Booking
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
            <a href="alat_fixed.php" class="nav-item active">
                <i class="bi bi-exclamation-triangle nav-icon"></i> Alat Rusak
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-exclamation-triangle"></i> Alat Rusak/Maintenance</h1>
            <div class="user-profile">
                <div class="profile-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span class="text-white"><?php echo $is_petugas ? 'Petugas' : 'Admin'; ?></span>
            </div>
        </div>
        
        <?php echo $message ?? ''; ?>
        
        <div class="row g-4">
            <?php foreach ($alat_fixed as $alat): ?>
            <div class="col-lg-4 col-md-6">
                <div class="shopee-card p-4 h-100">
                    <div class="text-center mb-4">
                        <?php if ($alat['foto']): ?>
                        <img src="../uploads/<?php echo htmlspecialchars($alat['foto']); ?>" class="rounded-circle mx-auto d-block mb-3" style="width:80px;height:80px;object-fit:cover;border:3px solid <?php echo $alat['kondisi']=='Rusak' ? '#dc3545' : '#ffc107'; ?>;">
                        <?php else: ?>
                        <div class="rounded-circle bg-warning bg-opacity-25 d-flex align-items-center justify-content-center mx-auto mb-3" style="width:80px;height:80px;">
                            <i class="bi bi-tools fs-4 text-warning"></i>
                        </div>
                        <?php endif; ?>
                    </div>
                    <h6 class="fw-bold mb-2"><?php echo htmlspecialchars($alat['nama']); ?></h6>
                    <p class="text-muted small mb-3"><?php echo htmlspecialchars(substr($alat['deskripsi'], 0, 100)); ?>...</p>
                    <div class="mb-3">
                        <span class="badge bg-<?php echo $alat['kondisi']=='Rusak' ? 'danger' : 'warning'; ?> w-100 py-2">
                            <i class="bi bi-<?php echo $alat['kondisi']=='Rusak' ? 'x-circle' : 'exclamation-triangle'; ?> me-1"></i>
                            <?php echo $alat['kondisi']; ?>
                        </span>
                    </div>
                    <form method="POST">
                        <input type="hidden" name="id" value="<?php echo $alat['id']; ?>">
                        <select name="kondisi" class="form-select mb-3">
                            <option value="Baik" <?php echo $alat['kondisi']=='Baik' ? 'selected' : ''; ?>>Baik (kembali ke stok)</option>
                            <option value="Rusak" <?php echo $alat['kondisi']=='Rusak' ? 'selected' : ''; ?>>Rusak</option>
                            <option value="Maintenance" <?php echo $alat['kondisi']=='Maintenance' ? 'selected' : ''; ?>>Maintenance</option>
                        </select>
                        <button name="update_status" class="btn btn-shopee w-100">
                            <i class="bi bi-check-circle me-2"></i>Update Status
                        </button>
                    </form>
                </div>
            </div>
            <?php endforeach; ?>
            <?php if (empty($alat_fixed)): ?>
            <div class="col-12">
                <div class="text-center py-5">
                    <i class="bi bi-check-circle fs-1 text-success mb-3"></i>
                    <h4 class="text-white-50">Semua alat dalam kondisi baik!</h4>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
