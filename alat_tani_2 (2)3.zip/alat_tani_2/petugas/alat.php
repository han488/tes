<?php
// petugas/alat.php - Copy from admin/alat.php with petugas branding
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    redirect('../index.php');
}

$is_petugas = $_SESSION['role'] == 'petugas';

$message = '';

if ($_POST) {
    if (isset($_POST['add'])) {
        $nama = trim($_POST['nama']);
        $kategori_id = (int)$_POST['kategori_id'] ?: null;
        $stok = (int)$_POST['stok'];
        $harga = (float)str_replace(',', '.', $_POST['harga']);
        $deskripsi = trim($_POST['deskripsi']);
        
        $foto = null;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            $foto_ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
            if (in_array($foto_ext, ['jpg','jpeg','png','webp'])) {
                $foto_name = 'alat_' . time() . '.' . $foto_ext;
                $foto_path = '../uploads/' . $foto_name;
                if (move_uploaded_file($_FILES['foto']['tmp_name'], $foto_path)) {
                    $foto = $foto_name;
                }
            }
        }
        
        $stmt = $pdo->prepare("INSERT INTO alat (nama, kategori_id, foto, stok, harga_sewa_per_hari, deskripsi) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nama, $kategori_id, $foto, $stok, $harga, $deskripsi]);
        $message = '<div class="alert alert-success shadow-lg">✅ Alat baru ditambahkan!</div>';

    } elseif (isset($_POST['edit'])) {
        $id = (int)$_POST['id'];
        $nama = trim($_POST['nama']);
        $kategori_id = (int)$_POST['kategori_id'] ?: null;
        $stok = (int)$_POST['stok'];
        $harga = (float)str_replace(',', '.', $_POST['harga']);
        $deskripsi = trim($_POST['deskripsi']);
        
        $stmt = $pdo->prepare("SELECT foto FROM alat WHERE id = ?");
        $stmt->execute([$id]);
        $current_foto = $stmt->fetchColumn();
        
        $foto = $current_foto;
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
            if ($current_foto && file_exists('../uploads/' . $current_foto)) {
                unlink('../uploads/' . $current_foto);
            }
            $foto_ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
            if (in_array($foto_ext, ['jpg','jpeg','png','webp'])) {
                $foto_name = 'alat_' . time() . '.' . $foto_ext;
                $foto_path = '../uploads/' . $foto_name;
                if (move_uploaded_file($_FILES['foto']['tmp_name'], $foto_path)) {
                    $foto = $foto_name;
                }
            }
        }
        
        $stmt = $pdo->prepare("UPDATE alat SET nama=?, kategori_id=?, foto=?, stok=?, harga_sewa_per_hari=?, deskripsi=? WHERE id=?");
        $stmt->execute([$nama, $kategori_id, $foto, $stok, $harga, $deskripsi, $id]);
        $message = '<div class="alert alert-success shadow-lg">✅ Alat diupdate!</div>';

    } elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("SELECT foto FROM alat WHERE id=?");
        $stmt->execute([$id]);
        $foto = $stmt->fetchColumn();
        if ($foto && file_exists('../uploads/' . $foto)) {
            unlink('../uploads/' . $foto);
        }
        $stmt = $pdo->prepare("DELETE FROM alat WHERE id=?");
        if ($stmt->execute([$id])) {
            $message = '<div class="alert alert-success shadow-lg">🗑️ Alat dihapus!</div>';
        }
    }
}

$alat_list = $pdo->query("SELECT a.*, k.nama as kat_nama FROM alat a LEFT JOIN kategori k ON a.kategori_id = k.id ORDER BY a.id DESC")->fetchAll();

$kategori_list = $pdo->query("SELECT * FROM kategori")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Alat - <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
    <link href="../assets/css/shopee-profile.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4"><?php echo $is_petugas ? 'Petugas Panel' : 'Admin Panel'; ?></h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Kelola Booking
            </a>
            <a href="alat.php" class="nav-item active">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-tools"></i> Manajemen Alat</h1>
            <div class="user-profile">
                <div class="profile-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span class="text-white"><?php echo $is_petugas ? 'Petugas' : 'Admin'; ?>, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <?php echo $message ?? ''; ?>
        
        <div class="mb-4">
            <button class="btn btn-warning shadow-lg px-4 py-2 text-white fw-bold" data-bs-toggle="modal" data-bs-target="#addModal" style="background: linear-gradient(135deg, #EE4D2D 0%, #FF6B35 100%); border: none;">
                <i class="bi bi-plus-circle me-2"></i> Tambah Alat
            </button>
        </div>

        <!-- Table & Modals same as admin/alat.php, omitted for brevity -->
        <div class="shopee-card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <!-- Table content same -->
                    </table>
                </div>
            </div>
        </div>
        <!-- Add/Edit Modals same -->
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- JS for edit modal same -->
</body>
</html>
