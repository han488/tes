<?php
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    redirect('../index.php');
}
$is_petugas = $_SESSION['role'] == 'petugas';

$total_alat = $pdo->query("SELECT COUNT(*) FROM alat")->fetchColumn();
$total_kategori = $pdo->query("SELECT COUNT(*) FROM kategori")->fetchColumn();
$total_booking = $pdo->query("SELECT COUNT(*) FROM peminjaman WHERE status = 'booking'")->fetchColumn();
$total_dipinjam = $pdo->query("SELECT COUNT(*) FROM peminjaman WHERE status = 'dipinjam'")->fetchColumn();
$total_pendapatan = $pdo->query("SELECT SUM(total_biaya + COALESCE(denda, 0)) FROM peminjaman WHERE status = 'dikembalikan'")->fetchColumn() ?: 0;
$total_peminjaman_bulanan = $pdo->query("SELECT COUNT(*) FROM peminjaman WHERE MONTH(created_at) = MONTH(CURDATE())")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> - Alat Tani</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
    <link href="../assets/css/dashboard.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4"><?php echo $is_petugas ? 'Petugas Panel' : 'Admin Panel'; ?></h4>
            <a href="dashboard.php" class="nav-item active">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Kelola Booking
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
            <a href="alat_fixed.php" class="nav-item">
                <i class="bi bi-wrench nav-icon"></i> Alat Rusak
            </a>
            <a href="users.php" class="nav-item">
                <i class="bi bi-people nav-icon"></i> Users
            </a>
            <a href="grafik-peminjaman.php" class="nav-item">
                <i class="bi bi-graph-up nav-icon"></i> Grafik
            </a>
            <a href="laporan.php" class="nav-item">
                <i class="bi bi-file-earmark-text nav-icon"></i> Laporan
            </a>
            <?php if (!$is_petugas): ?>
            <a href="settings.php" class="nav-item">
                <i class="bi bi-gear nav-icon"></i> Settings
            </a>
            <?php endif; ?>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0">Dashboard <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?></h1>
            <div class="user-profile">
                <div class="profile-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span class="text-white">Halo, <?php echo htmlspecialchars($_SESSION['username']); ?> (<?php echo ucfirst($_SESSION['role']); ?>)</span>
            </div>
        </div>
        
        <div class="row g-4 mb-5">
            <div class="col-xl-3 col-md-6">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">🛠️</div>
                    <div class="h5 fw-bold text-shopee mb-1"><?php echo $total_alat; ?></div>
                    <div class="text-muted">Total Alat</div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">📅</div>
                    <div class="h5 fw-bold text-shopee mb-1"><?php echo $total_booking; ?></div>
                    <div class="text-muted">Booking Menunggu</div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">🔧</div>
                    <div class="h5 fw-bold text-shopee mb-1"><?php echo $total_dipinjam; ?></div>
                    <div class="text-muted">Sedang Dipinjam</div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="shopee-card h-100 p-4 text-center">
                    <div class="mb-3" style="font-size: 2.5rem;">💰</div>
                    <div class="h5 fw-bold text-success mb-1">Rp <?php echo number_format($total_pendapatan, 0, ',', '.'); ?></div>
                    <div class="text-muted">Pendapatan Total</div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-8">
                <div class="shopee-card p-4">
                    <h5 class="fw-bold text-shopee mb-4">Aktivitas Terbaru</h5>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Alat</th>
                                    <th>Status</th>
                                    <th>Tgl Booking</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $recent = $pdo->query("SELECT p.*, u.username, a.nama as alat_nama FROM peminjaman p 
                                    JOIN users u ON p.user_id = u.id 
                                    JOIN alat a ON p.alat_id = a.id 
                                    ORDER BY p.created_at DESC LIMIT 10")->fetchAll();
                                foreach ($recent as $p): ?>
                                <tr>
                                    <td><span class="badge bg-light text-dark">#<?php echo $p['id']; ?></span></td>
                                    <td><?php echo htmlspecialchars($p['username']); ?></td>
                                    <td><?php echo htmlspecialchars($p['alat_nama']); ?></td>
                                    <td><span class="badge bg-<?php echo $p['status']=='booking' ? 'warning' : ($p['status']=='dipinjam' ? 'info' : 'success'); ?>">
                                        <?php echo ucfirst($p['status']); ?>
                                    </span></td>
                                    <td><?php echo date('d/m H:i', strtotime($p['created_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row g-4">
                    <div class="col-12">
                        <a href="booking.php" class="shopee-card h-100 p-4 text-center text-decoration-none">
                            <div class="mb-3" style="font-size: 2.5rem;">📋</div>
                            <div class="h5 fw-bold text-shopee mb-1"><?php echo $total_booking; ?> Booking</div>
                            <div class="text-muted mb-3">Menunggu Persetujuan</div>
                            <div class="btn btn-shopee w-100">Kelola</div>
                        </a>
                    </div>
                    <div class="col-12">
                        <a href="alat.php" class="shopee-card h-100 p-4 text-center text-decoration-none">
                            <div class="mb-3" style="font-size: 2.5rem;">🛠️</div>
                            <div class="h5 fw-bold text-shopee mb-1">Kelola Alat</div>
                            <div class="text-muted mb-3">Tambah/Edit/Stok</div>
                            <div class="btn btn-shopee w-100">Buka Panel</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
