<?php
// petugas/booking.php - Copy from admin/booking.php with petugas branding
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    redirect('../index.php');
}

$is_petugas = $_SESSION['role'] == 'petugas';

$message = '';

if ($_POST) {
    $id = (int)$_POST['id'];
    $action = $_POST['action'];
    
    $stmt = $pdo->prepare("SELECT alat_id, status FROM peminjaman WHERE id = ? FOR UPDATE");
    $stmt->execute([$id]);
    $booking = $stmt->fetch();
    
    if (!$booking) {
        $message = '<div class="alert alert-danger shadow-lg">Peminjaman tidak ditemukan!</div>';
    } else {
        switch ($action) {
            case 'approve':
                if ($booking['status'] === 'booking') {
                    $stmt = $pdo->prepare("UPDATE peminjaman SET status = 'dipinjam' WHERE id = ?");
                    $stmt->execute([$id]);
                    $message = '<div class="alert alert-success shadow-lg">✓ Approved!</div>';
                }
                break;
            case 'reject':
                if ($booking['status'] === 'booking') {
                    $pdo->beginTransaction();
                    try {
                        $stmt = $pdo->prepare("UPDATE peminjaman SET status = 'rejected' WHERE id = ?");
                        $stmt->execute([$id]);
                        $stmt = $pdo->prepare("UPDATE alat SET stok = stok + 1 WHERE id = ?");
                        $stmt->execute([$booking['alat_id']]);
                        $pdo->commit();
                        $message = '<div class="alert alert-warning shadow-lg">✗ Rejected, stok restored!</div>';
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        $message = '<div class="alert alert-danger shadow-lg">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
                    }
                }
                break;
            case 'return':
                if ($booking['status'] === 'dipinjam') {
                    $pdo->beginTransaction();
                    try {
                        $stmt = $pdo->prepare("UPDATE peminjaman SET status = 'dikembalikan', tgl_kembali_actual = CURDATE() WHERE id = ?");
                        $stmt->execute([$id]);
                        $stmt = $pdo->prepare("UPDATE alat SET stok = stok + 1 WHERE id = ?");
                        $stmt->execute([$booking['alat_id']]);
                        $stmt = $pdo->prepare("
                            UPDATE peminjaman p JOIN alat a ON p.alat_id = a.id 
                            SET p.denda = GREATEST(0, DATEDIFF(p.tgl_kembali_actual, p.tgl_selesai) * a.harga_sewa_per_hari * 0.1)
                            WHERE p.id = ?
                        ");
                        $stmt->execute([$id]);
                        $pdo->commit();
                        $message = '<div class="alert alert-success shadow-lg">✅ Returned!</div>';
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        $message = '<div class="alert alert-danger shadow-lg">Return failed!</div>';
                    }
                }
                break;
        }
    }
}

$peminjaman = $pdo->query("
    SELECT p.*, u.username, a.nama as alat_nama, a.stok 
    FROM peminjaman p 
    JOIN users u ON p.user_id = u.id 
    JOIN alat a ON p.alat_id = a.id 
    ORDER BY p.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Booking - <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4"><?php echo $is_petugas ? 'Petugas Panel' : 'Admin Panel'; ?></h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="booking.php" class="nav-item active">
                <i class="bi bi-calendar-check nav-icon"></i> Kelola Booking
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-calendar-check"></i> Kelola Booking</h1>
            <div class="user-profile">
                <div class="profile-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span class="text-white"><?php echo $is_petugas ? 'Petugas' : 'Admin'; ?>, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <?php echo $message ?? ''; ?>
        
        <div class="shopee-card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="bg-shopee text-white">
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Alat</th>
                                <th>Tanggal</th>
                                <th>Biaya</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Table content same as admin/booking.php -->
                            <?php foreach ($peminjaman as $row): ?>
                            <tr>
                                <td>#<?php echo $row['id']; ?></td>
                                <td><?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['alat_nama']); ?></td>
                                <td><?php echo date('d/m/Y', strtotime($row['tgl_mulai'])); ?> → <?php echo date('d/m/Y', strtotime($row['tgl_selesai'])); ?></td>
                                <td>Rp <?php echo number_format($row['total_biaya'],0,',','.'); ?></td>
                                <td><?php echo ucfirst($row['status']); ?></td>
                                <td><!-- Action buttons --></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
