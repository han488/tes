<?php
// petugas/settings.php - Limited settings for petugas (no sensitive changes)
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    redirect('../index.php');
}

$is_petugas = $_SESSION['role'] == 'petugas';

if ($_SESSION['role'] != 'admin') {
    $message = '<div class="alert alert-warning">Petugas tidak bisa ubah settings sistem.</div>';
}

// Fetch settings (view only for petugas)
$stmt = $pdo->query("SELECT * FROM settings ORDER BY name");
$settings_list = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4"><?php echo $is_petugas ? 'Petugas Panel' : 'Admin Panel'; ?></h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Alat
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Booking
            </a>
            <a href="settings.php" class="nav-item active">
                <i class="bi bi-gear nav-icon"></i> Settings
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-gear"></i> System Settings</h1>
            <div class="user-profile">
                <div class="profile-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span class="text-white"><?php echo $is_petugas ? 'Petugas' : 'Admin'; ?></span>
            </div>
        </div>
        
        <?php echo $message ?? ''; ?>
        
        <div class="shopee-card">
            <div class="card-body">
                <h5 class="card-title mb-4">Konfigurasi Sistem</h5>
                <div class="row g-3">
                    <?php foreach ($settings_list as $set): ?>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center p-3 rounded border">
                            <div class="flex-grow-1">
                                <div class="fw-bold"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $set['name']))); ?></div>
                                <small class="text-muted"><?php echo $set['value']; ?></small>
                            </div>
                            <?php if ($_SESSION['role'] == 'admin'): ?>
                            <button class="btn btn-sm btn-outline-primary ms-2">Edit</button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
