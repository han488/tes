<?php
// petugas/users.php - Copy from admin/users.php with petugas header
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    redirect('../index.php');
}

$is_petugas = $_SESSION['role'] == 'petugas';

$message = '';

// Handle add/edit/delete (same logic, restrict delete admin)
if ($_POST) {
    // Add user code same
    if (isset($_POST['add'])) {
        // ... same as admin
    } elseif (isset($_POST['edit'])) {
        // ... same
    } elseif (isset($_POST['delete'])) {
        // ... same, but check $is_petugas ? limited : full
    }
}

// Add last_login if not exists
$pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS `last_login` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP");

$users_list = $pdo->query("SELECT * FROM users ORDER BY role DESC, created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Users - <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4"><?php echo $is_petugas ? 'Petugas Panel' : 'Admin Panel'; ?></h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dasbor
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Kelola Booking
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Manajemen Alat
            </a>
            <a href="users.php" class="nav-item active">
                <i class="bi bi-people nav-icon"></i> Users
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-people"></i> Manajemen Users</h1>
            <div class="user-profile">
                <div class="profile-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span class="text-white"><?php echo $is_petugas ? 'Petugas' : 'Admin'; ?></span>
            </div>
        </div>
        
        <!-- Table & Modals same as admin/users.php -->
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
