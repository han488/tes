<?php
// petugas/laporan.php - Monthly report copy from admin/
require_once '../config/koneksi.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'petugas'])) {
    redirect('../index.php');
}

$is_petugas = $_SESSION['role'] == 'petugas';

// Get settings
$stmt = $pdo->query("SELECT name, value FROM settings");
$settings = [];
foreach ($stmt->fetchAll() as $row) {
    $settings[$row['name']] = $row['value'];
}

$month = $_GET['bulan'] ?? date('Y-m');
$year = date('Y', strtotime($month));
$month_name = date('F Y', strtotime($month));

// Fetch monthly report
$stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_transaksi,
        SUM(total_biaya) as total_revenue,
        SUM(denda) as total_denda,
        SUM(total_biaya + denda) as grand_total,
        COUNT(CASE WHEN status = 'dikembalikan' THEN 1 END) as completed,
        COUNT(CASE WHEN status = 'dipinjam' THEN 1 END) as active,
        COUNT(CASE WHEN status = 'booking' THEN 1 END) as pending
    FROM peminjaman 
    WHERE YEAR(created_at) = ? AND MONTH(created_at) = ?
");
$stmt->execute([$year, date('m', strtotime($month))]);
$summary = $stmt->fetch();

// Top users
$month_num = date('m', strtotime($month));
$top_users = $pdo->prepare("
    SELECT u.username, COUNT(p.id) as transaksi, SUM(p.total_biaya + p.denda) as total_spent
    FROM peminjaman p JOIN users u ON p.user_id = u.id
    WHERE YEAR(p.created_at) = ? AND MONTH(p.created_at) = ?
    GROUP BY u.id ORDER BY total_spent DESC LIMIT 5
");
$top_users->execute([$year, $month_num]);
$top_users = $top_users->fetchAll();

// Top alat
$top_alat = $pdo->prepare("
    SELECT a.nama, COUNT(p.id) as dipinjam, SUM(p.total_biaya) as revenue
    FROM peminjaman p JOIN alat a ON p.alat_id = a.id
    WHERE YEAR(p.created_at) = ? AND MONTH(p.created_at) = ?
    GROUP BY a.id ORDER BY revenue DESC LIMIT 5
");
$top_alat->execute([$year, $month_num]);
$top_alat = $top_alat->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - <?php echo $is_petugas ? 'Petugas' : 'Admin'; ?> Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/shopee.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <div style="margin-bottom: 3rem;">
            <h4 class="text-white mb-4"><?php echo $is_petugas ? 'Petugas Panel' : 'Admin Panel'; ?></h4>
            <a href="dashboard.php" class="nav-item">
                <i class="bi bi-house-door nav-icon"></i> Dashboard
            </a>
            <a href="alat.php" class="nav-item">
                <i class="bi bi-tools nav-icon"></i> Alat
            </a>
            <a href="booking.php" class="nav-item">
                <i class="bi bi-calendar-check nav-icon"></i> Booking
            </a>
            <a href="laporan.php" class="nav-item active">
                <i class="bi bi-file-earmark-text nav-icon"></i> Laporan
            </a>
            <a href="../logout.php" class="nav-item">
                <i class="bi bi-box-arrow-right nav-icon"></i> Logout
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1 class="text-white mb-0"><i class="bi bi-file-earmark-text"></i> Laporan Bulanan</h1>
            <div class="user-profile">
                <div class="profile-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                <span class="text-white"><?php echo $is_petugas ? 'Petugas' : 'Admin'; ?></span>
            </div>
        </div>

        <!-- Summary cards, top users/alat same as admin/laporan.php -->
        <div class="row g-4">
            <div class="col-lg-6">
                <div class="shopee-card">
                    <h6>User Teraktif Bulan Ini</h6>
                    <!-- List top users -->
                </div>
            </div>
            <div class="col-lg-6">
                <div class="shopee-card">
                    <h6>Alat Terpopuler</h6>
                    <!-- List top alat -->
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
